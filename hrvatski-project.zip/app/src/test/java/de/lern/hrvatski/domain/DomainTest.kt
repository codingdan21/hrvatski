package de.lern.hrvatski.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class DomainTest {

    @Test
    fun exactAnswerIsCorrect() {
        assertEquals(Verdict.CORRECT, AnswerChecker.check(" Jabuku. ", listOf("jabuku"), lenient = false).verdict)
    }

    @Test
    fun missingDiacriticsDependOnLenientMode() {
        val strict = AnswerChecker.check("cevapi", listOf("ćevapi"), lenient = false)
        val lenient = AnswerChecker.check("cevapi", listOf("ćevapi"), lenient = true)
        assertEquals(Verdict.WRONG, strict.verdict)
        assertEquals(true, strict.diacriticsOnly)
        assertEquals(Verdict.ALMOST, lenient.verdict)
    }

    @Test
    fun djCountsAsD() {
        assertEquals(Verdict.ALMOST, AnswerChecker.check("gospodjo", listOf("gospođo"), lenient = true).verdict)
    }

    @Test
    fun wrongCaseFormIsWrong() {
        assertEquals(Verdict.WRONG, AnswerChecker.check("jabuka", listOf("jabuku"), lenient = true).verdict)
    }

    @Test
    fun leitnerBoxes() {
        assertEquals(1, Leitner.nextBox(0, true))
        assertEquals(4, Leitner.nextBox(3, true))
        assertEquals(5, Leitner.nextBox(5, true))
        assertEquals(1, Leitner.nextBox(4, false))
        assertEquals(LearnStatus.NEW, Leitner.status(null))
        assertEquals(LearnStatus.LEARNING, Leitner.status(2))
        assertEquals(LearnStatus.KNOWN, Leitner.status(3))
        assertEquals(3 * Leitner.DAY_MS, Leitner.dueAt(3, 0))
    }

    @Test
    fun streakCounting() {
        assertEquals(3, Streak.current(setOf(8, 9, 10), today = 10))
        assertEquals(3, Streak.current(setOf(8, 9, 10), today = 11))
        assertEquals(0, Streak.current(setOf(8, 9), today = 11))
    }

    @Test
    fun searchFolding() {
        assertEquals(TextNormalizer.fold("ćevapi"), TextNormalizer.fold("cevapi"))
        assertEquals("dakovo", TextNormalizer.fold("Đakovo"))
    }
}
