package de.lern.hrvatski.data.seed

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Shape of assets/content/vocabulary.json. See README for how to edit it. */
@Serializable
data class SeedFile(
    val categories: List<SeedCategory>,
    val words: List<SeedWord>,
    val sentences: List<SeedSentence> = emptyList(),
)

@Serializable
data class SeedCategory(
    val id: String,
    val de: String,
    val hr: String,
)

@Serializable
data class SeedWord(
    val id: String,
    val cat: String,
    val de: String,
    val hr: String,
    val gender: String? = null,
    val info: String? = null,
    val exDe: String? = null,
    val exHr: String? = null,
)

@Serializable
data class SeedSentence(
    val id: String,
    val cat: String,
    val word: String? = null,
    val text: String,
    val answer: String,
    val alt: List<String> = emptyList(),
    val distractors: List<String> = emptyList(),
    val hint: String,
    val base: String,
    val note: String = "",
    val de: String = "",
)

val AppJson = Json {
    ignoreUnknownKeys = true
}
