package de.lern.hrvatski.data.seed

import android.content.Context
import androidx.room.withTransaction
import de.lern.hrvatski.data.db.AppDatabase
import de.lern.hrvatski.data.db.CategoryEntity
import de.lern.hrvatski.data.db.SentenceEntity
import de.lern.hrvatski.data.db.SettingEntity
import de.lern.hrvatski.data.db.WordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * Copies the bundled vocabulary JSON into Room.
 *
 * The sync runs whenever the JSON content changes (detected via a SHA-256 hash), so editing
 * the file and rebuilding the app is enough – no version number to bump. Learning progress
 * lives in separate tables and is kept; only progress of words that were removed from the
 * JSON is deleted.
 */
class ContentSeeder(private val context: Context, private val db: AppDatabase) {

    suspend fun syncIfNeeded() = withContext(Dispatchers.IO) {
        val raw = context.assets.open(ASSET_PATH).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val hash = sha256(raw)
        val userDao = db.userDao()
        val contentDao = db.contentDao()
        if (userDao.getSetting(KEY_HASH) == hash && contentDao.wordIds().isNotEmpty()) return@withContext

        val seed = AppJson.decodeFromString(SeedFile.serializer(), raw)
        validate(seed)

        val categories = seed.categories.mapIndexed { i, c -> CategoryEntity(c.id, c.de, c.hr, i) }
        val words = seed.words.mapIndexed { i, w ->
            WordEntity(
                id = w.id, categoryId = w.cat, german = w.de, croatian = w.hr, gender = w.gender,
                info = w.info, exampleDe = w.exDe, exampleHr = w.exHr, sortOrder = i,
            )
        }
        val sentences = seed.sentences.mapIndexed { i, s ->
            SentenceEntity(
                id = s.id, categoryId = s.cat, wordId = s.word, text = s.text, answer = s.answer,
                alternatives = s.alt, distractors = s.distractors, hint = s.hint, baseForm = s.base,
                note = s.note, translation = s.de, sortOrder = i,
            )
        }

        db.withTransaction {
            contentDao.upsertCategories(categories)
            contentDao.upsertWords(words)
            contentDao.upsertSentences(sentences)

            val keepCategories = categories.map { it.id }.toSet()
            val keepWords = words.map { it.id }.toSet()
            val keepSentences = sentences.map { it.id }.toSet()
            contentDao.categoryIds().filterNot { it in keepCategories }.forEach { contentDao.deleteCategory(it) }
            contentDao.wordIds().filterNot { it in keepWords }.forEach {
                contentDao.deleteWord(it)
                userDao.deleteProgressFor(it)
            }
            contentDao.sentenceIds().filterNot { it in keepSentences }.forEach { contentDao.deleteSentence(it) }

            userDao.putSetting(SettingEntity(KEY_HASH, hash))
        }
    }

    /** Fails early with a readable message if the JSON references unknown ids. */
    private fun validate(seed: SeedFile) {
        val categoryIds = seed.categories.map { it.id }.toSet()
        val wordIds = mutableSetOf<String>()
        seed.words.forEach { w ->
            require(w.cat in categoryIds) { "Wort ${w.id}: unbekannte Kategorie '${w.cat}'" }
            require(wordIds.add(w.id)) { "Wort-ID doppelt: ${w.id}" }
        }
        val sentenceIds = mutableSetOf<String>()
        seed.sentences.forEach { s ->
            require(s.cat in categoryIds) { "Satz ${s.id}: unbekannte Kategorie '${s.cat}'" }
            require(s.word == null || s.word in wordIds) { "Satz ${s.id}: unbekanntes Wort '${s.word}'" }
            require(s.text.contains("___")) { "Satz ${s.id}: Lücke ___ fehlt" }
            require(sentenceIds.add(s.id)) { "Satz-ID doppelt: ${s.id}" }
        }
    }

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    companion object {
        const val ASSET_PATH = "content/vocabulary.json"
        private const val KEY_HASH = "content_hash"
    }
}
