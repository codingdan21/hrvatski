package de.lern.hrvatski.domain

import java.text.Normalizer
import java.util.Locale

/**
 * Text helpers shared by answer checking and search.
 *
 * - [normalize] keeps diacritics but ignores case, surrounding punctuation and extra spaces.
 * - [fold] additionally removes Croatian diacritics (č, ć → c, š → s, ž → z, đ → d) and
 *   treats the common keyboard fallback "dj" like "đ". Used for lenient answers and search,
 *   so "cevapi" finds "ćevapi".
 */
object TextNormalizer {
    private val combiningMarks = Regex("\\p{Mn}+")
    private val whitespace = Regex("\\s+")
    private const val PUNCT = "\\p{Punct}¿¡„“”‚‘’«»…–—"
    private val edgePunctuation = Regex("^[$PUNCT]+|[$PUNCT]+$")

    fun normalize(input: String): String =
        input.trim()
            .lowercase(Locale.ROOT)
            .replace(whitespace, " ")
            .replace(edgePunctuation, "")
            .trim()

    fun stripDiacritics(input: String): String {
        // đ/Đ is a separate letter in Unicode (not d + combining mark), so replace it manually.
        val replaced = input.replace("đ", "d").replace("Đ", "D")
        return Normalizer.normalize(replaced, Normalizer.Form.NFD).replace(combiningMarks, "")
    }

    fun fold(input: String): String = stripDiacritics(normalize(input)).replace("dj", "d")
}
