package de.lern.hrvatski.ui.list

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import de.lern.hrvatski.domain.LearnStatus
import de.lern.hrvatski.ui.common.Hairline
import de.lern.hrvatski.ui.common.Pill
import de.lern.hrvatski.ui.common.StatusDot
import de.lern.hrvatski.ui.common.repoFactory
import de.lern.hrvatski.ui.common.shortGender

@Composable
fun ListScreen(vm: ListViewModel = viewModel(factory = repoFactory { ListViewModel(it) })) {
    val filters by vm.filters.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val groups by vm.groups.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = filters.query,
            onValueChange = vm::setQuery,
            placeholder = { Text("Suchen – Deutsch oder Kroatisch") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            trailingIcon = {
                if (filters.query.isNotEmpty()) {
                    IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Outlined.Close, contentDescription = "Leeren") }
                }
            },
            singleLine = true,
            shape = CircleShape,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedBorderColor = MaterialTheme.colorScheme.onSurface,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Pill("Alle", filters.category == null, onClick = { vm.setCategory(null) }) }
            items(categories, key = { it.id }) { c ->
                Pill(c.nameDe, filters.category == c.id, onClick = { vm.setCategory(c.id) })
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val statusOptions = listOf(null to "Alle", LearnStatus.NEW to "Neu", LearnStatus.LEARNING to "Am Lernen", LearnStatus.KNOWN to "Gelernt")
            items(statusOptions) { (status, label) ->
                Pill(label, filters.status == status, onClick = { vm.setStatus(status) })
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
            Spacer(Modifier.width(22.dp))
            ColumnLabel("Deutsch", Modifier.weight(1f))
            ColumnLabel("Hrvatski", Modifier.weight(1f))
        }
        Hairline()

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (groups.isEmpty()) {
                item {
                    Text(
                        "Keine Treffer.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                }
            }
            groups.forEach { group ->
                // While searching, everything is expanded so no hit is hidden.
                val expanded = filters.query.isNotBlank() || group.category.id !in filters.collapsed
                item(key = "header_${group.category.id}") {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.toggle(group.category.id) }
                            .padding(start = 20.dp, end = 12.dp, top = 20.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(group.category.nameDe, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${group.category.nameHr} · ${group.rows.size}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Icon(
                            if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                            contentDescription = if (expanded) "Einklappen" else "Ausklappen",
                        )
                    }
                }
                if (expanded) {
                    items(group.rows, key = { it.word.id }) { row -> WordRowItem(row) }
                }
            }
        }
    }
}

@Composable
private fun ColumnLabel(text: String, modifier: Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier,
    )
}

@Composable
private fun WordRowItem(row: WordRow) {
    Column {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StatusDot(row.status)
            Spacer(Modifier.width(12.dp))
            Text(row.word.german, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f).padding(end = 8.dp))
            Column(Modifier.weight(1f)) {
                Text(row.word.croatian, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                val gender = shortGender(row.word.gender)
                if (gender != null) {
                    Text(gender, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Hairline(Modifier.padding(start = 42.dp))
    }
}
