package de.lern.hrvatski.ui.grammar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.data.db.LessonProgressEntity
import de.lern.hrvatski.data.grammar.Lesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GrammarListViewModel(repo: Repository) : ViewModel() {
    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    val progress: StateFlow<Map<String, LessonProgressEntity>> =
        repo.lessonProgress.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    init {
        viewModelScope.launch { _lessons.value = repo.lessons() }
    }
}

data class LessonUiState(
    val lesson: Lesson? = null,
    /** Question index → chosen option index. */
    val answers: Map<Int, Int> = emptyMap(),
    val saved: Boolean = false,
) {
    val quizSize: Int get() = lesson?.quiz?.size ?: 0
    val score: Int get() = answers.count { (q, a) -> lesson?.quiz?.getOrNull(q)?.answer == a }
    val quizDone: Boolean get() = quizSize > 0 && answers.size == quizSize
}

class LessonViewModel(private val repo: Repository, private val lessonId: String) : ViewModel() {
    private val _state = MutableStateFlow(LessonUiState())
    val state: StateFlow<LessonUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val lesson = repo.lessons().firstOrNull { it.id == lessonId }
            _state.update { it.copy(lesson = lesson) }
        }
    }

    fun answer(questionIndex: Int, optionIndex: Int) {
        val s = _state.value
        if (questionIndex in s.answers) return // one try per question
        val newState = s.copy(answers = s.answers + (questionIndex to optionIndex))
        _state.value = newState
        // As soon as every question is answered, the lesson counts as completed.
        if (newState.quizDone && !newState.saved) {
            _state.update { it.copy(saved = true) }
            viewModelScope.launch { repo.saveLessonResult(lessonId, newState.score, newState.quizSize) }
        }
    }

    fun resetQuiz() = _state.update { it.copy(answers = emptyMap(), saved = false) }
}
