package de.lern.hrvatski.domain

object Streak {
    /**
     * Number of consecutive active days ending today. If today has no activity yet,
     * the streak still counts from yesterday, so it doesn't "break" in the morning.
     * Days are epoch days (LocalDate.toEpochDay()).
     */
    fun current(activeDays: Set<Long>, today: Long): Int {
        var day = if (today in activeDays) today else today - 1
        var count = 0
        while (day in activeDays) {
            count++
            day--
        }
        return count
    }
}
