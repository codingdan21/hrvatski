package de.lern.hrvatski.ui.cards

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.offset
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import de.lern.hrvatski.data.db.WordEntity
import de.lern.hrvatski.domain.Direction
import de.lern.hrvatski.ui.common.PillFlow
import de.lern.hrvatski.ui.common.SectionLabel
import de.lern.hrvatski.ui.common.Segmented
import de.lern.hrvatski.ui.common.StatBlock
import de.lern.hrvatski.ui.common.genderLabel
import de.lern.hrvatski.ui.common.repoFactory
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun CardsScreen(vm: CardsViewModel = viewModel(factory = repoFactory { CardsViewModel(it) })) {
    val state by vm.state.collectAsStateWithLifecycle()
    val counts by vm.counts.collectAsStateWithLifecycle()
    val session = state.session

    when {
        session == null -> CardsSetup(state, counts, vm)
        session.finished -> SessionSummary(session, onAgain = { vm.endSession(); vm.start(practiceAll = true) }, onDone = vm::endSession)
        else -> CardSessionView(session, state.direction, vm)
    }
}

@Composable
private fun CardsSetup(state: CardsUiState, counts: DeckCounts, vm: CardsViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 8.dp),
    ) {
        SectionLabel("Kategorie")
        PillFlow(
            options = listOf<Pair<String?, String>>(null to "Alle") + state.categories.map { it.id to it.nameDe },
            selected = state.selectedCategory,
            onSelect = vm::selectCategory,
        )

        Spacer(Modifier.height(28.dp))
        SectionLabel("Richtung")
        Segmented(
            options = listOf("Deutsch → Kroatisch", "Kroatisch → Deutsch"),
            selectedIndex = if (state.direction == Direction.DE_TO_HR) 0 else 1,
            onSelect = { vm.setDirection(if (it == 0) Direction.DE_TO_HR else Direction.HR_TO_DE) },
        )

        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Mischen", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Karten in zufälliger Reihenfolge",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = state.shuffle, onCheckedChange = vm::setShuffle)
        }

        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth()) {
            StatBlock(counts.due.toString(), "fällig", Modifier.weight(1f))
            StatBlock(counts.fresh.toString(), "neu", Modifier.weight(1f))
            StatBlock("${counts.known}/${counts.total}", "gelernt", Modifier.weight(1f))
        }

        Spacer(Modifier.height(32.dp))
        if (state.nothingDue || (counts.due == 0 && counts.fresh == 0 && counts.total > 0)) {
            Text(
                "Alles erledigt – in dieser Kategorie ist gerade nichts fällig.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { vm.start(practiceAll = true) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Trotzdem üben")
            }
        } else {
            Button(
                onClick = { vm.start() },
                enabled = counts.total > 0,
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                Text("Lernen starten", style = MaterialTheme.typography.titleMedium)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Bis zu ${CardsViewModel.SESSION_SIZE} Karten pro Runde: zuerst fällige Wiederholungen, dann neue Wörter.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CardSessionView(session: CardSession, direction: Direction, vm: CardsViewModel) {
    val word = session.current ?: return
    val doneFraction = session.knownCount.toFloat() / session.total.coerceAtLeast(1)

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::endSession) { Icon(Icons.Outlined.Close, contentDescription = "Runde beenden") }
            LinearProgressIndicator(
                progress = { doneFraction },
                modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = MaterialTheme.colorScheme.onSurface,
                trackColor = MaterialTheme.colorScheme.outlineVariant,
            )
            Spacer(Modifier.width(16.dp))
            Text("${session.knownCount}/${session.total}", style = MaterialTheme.typography.labelLarge)
        }
        Spacer(Modifier.height(16.dp))

        // key(): a fresh card composable (offset & flip reset) for every review, even if the same word repeats.
        key(session.reviews) {
            SwipeFlipCard(
                front = frontFace(word, direction),
                back = backFace(word, direction),
                flipped = session.flipped,
                onFlip = vm::flip,
                onSwiped = vm::answer,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
        }

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.answer(false) }, modifier = Modifier.weight(1f).height(56.dp)) {
                Icon(Icons.Outlined.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Nochmal")
            }
            Button(onClick = { vm.answer(true) }, modifier = Modifier.weight(1f).height(56.dp)) {
                Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Gewusst")
            }
        }
        Text(
            "Tippen zum Umdrehen · nach links wischen = nochmal · nach rechts = gewusst",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        )
    }
}

private data class CardFace(val label: String, val main: String, val sub: String?, val extra: String?, val extraSub: String?)

private fun frontFace(word: WordEntity, direction: Direction): CardFace = when (direction) {
    Direction.DE_TO_HR -> CardFace("DEUTSCH", word.german, null, null, null)
    Direction.HR_TO_DE -> CardFace("HRVATSKI", word.croatian, genderLabel(word.gender), null, null)
}

private fun backFace(word: WordEntity, direction: Direction): CardFace = when (direction) {
    Direction.DE_TO_HR -> CardFace(
        label = "HRVATSKI",
        main = word.croatian,
        sub = listOfNotNull(genderLabel(word.gender), word.info).joinToString(" · ").ifBlank { null },
        extra = word.exampleHr,
        extraSub = word.exampleDe,
    )
    Direction.HR_TO_DE -> CardFace(
        label = "DEUTSCH",
        main = word.german,
        sub = word.info,
        extra = word.exampleHr,
        extraSub = word.exampleDe,
    )
}

/**
 * Card that flips on tap (3D rotation around the Y axis) and can be swiped left/right.
 * The front is white-on-black outline style; the back is inverted, so the flip is clearly visible.
 */
@Composable
private fun SwipeFlipCard(
    front: CardFace,
    back: CardFace,
    flipped: Boolean,
    onFlip: () -> Unit,
    onSwiped: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }
    val currentOnSwiped by rememberUpdatedState(onSwiped)
    val rotation by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "flip",
    )
    val density = LocalDensity.current.density
    val colors = MaterialTheme.colorScheme
    val showingBack = rotation > 90f
    val shape = RoundedCornerShape(28.dp)

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.value.roundToInt(), 0) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val threshold = size.width * 0.28f
                        scope.launch {
                            when {
                                offsetX.value > threshold -> {
                                    offsetX.animateTo(size.width * 1.5f, tween(180))
                                    currentOnSwiped(true)
                                }
                                offsetX.value < -threshold -> {
                                    offsetX.animateTo(-size.width * 1.5f, tween(180))
                                    currentOnSwiped(false)
                                }
                                else -> offsetX.animateTo(0f, spring())
                            }
                        }
                    },
                    onDragCancel = { scope.launch { offsetX.animateTo(0f, spring()) } },
                ) { change, dragAmount ->
                    change.consume()
                    scope.launch { offsetX.snapTo(offsetX.value + dragAmount) }
                }
            }
            .graphicsLayer {
                rotationZ = offsetX.value / 60f
                rotationY = rotation
                cameraDistance = 16f * density
            }
            .clip(shape)
            .background(if (showingBack) colors.onSurface else colors.surface)
            .border(1.dp, if (showingBack) colors.onSurface else colors.outlineVariant, shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onFlip),
        contentAlignment = Alignment.Center,
    ) {
        // On the back side, counter-rotate the content so the text isn't mirrored.
        Box(
            Modifier.fillMaxSize().graphicsLayer { rotationY = if (showingBack) 180f else 0f },
            contentAlignment = Alignment.Center,
        ) {
            FaceContent(if (showingBack) back else front, inverted = showingBack)

            // Swipe feedback in the top corners.
            val swipe = offsetX.value
            if (swipe > 40f) {
                SwipeTag("GEWUSST", Modifier.align(Alignment.TopStart), inverted = showingBack)
            } else if (swipe < -40f) {
                SwipeTag("NOCHMAL", Modifier.align(Alignment.TopEnd), inverted = showingBack)
            }
        }
    }
}

@Composable
private fun SwipeTag(text: String, modifier: Modifier, inverted: Boolean) {
    val color = if (inverted) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = color,
        modifier = modifier
            .padding(20.dp)
            .border(1.5.dp, color, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
private fun FaceContent(face: CardFace, inverted: Boolean) {
    val colors = MaterialTheme.colorScheme
    val main = if (inverted) colors.surface else colors.onSurface
    val muted = if (inverted) colors.outline else colors.onSurfaceVariant
    Column(
        Modifier.fillMaxWidth().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(face.label, style = MaterialTheme.typography.labelSmall, color = muted)
        Spacer(Modifier.height(20.dp))
        Text(face.main, style = MaterialTheme.typography.displaySmall, color = main, textAlign = TextAlign.Center)
        face.sub?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium, color = muted, textAlign = TextAlign.Center)
        }
        face.extra?.let {
            Spacer(Modifier.height(28.dp))
            Box(Modifier.width(32.dp).height(1.dp).background(muted))
            Spacer(Modifier.height(20.dp))
            Text(it, style = MaterialTheme.typography.bodyLarge, color = main, textAlign = TextAlign.Center)
            face.extraSub?.let { sub ->
                Spacer(Modifier.height(4.dp))
                Text(sub, style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, color = muted, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun SessionSummary(session: CardSession, onAgain: () -> Unit, onDone: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Runde geschafft", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "${session.total} Karten · ${session.reviews} Antworten",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(40.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Fertig") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onAgain, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Noch eine Runde") }
    }
}
