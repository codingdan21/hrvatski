package de.lern.hrvatski.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import de.lern.hrvatski.HrvatskiApplication
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.domain.LearnStatus

/** Builds a ViewModel factory that hands the app-wide [Repository] to the ViewModel. */
inline fun <reified VM : ViewModel> repoFactory(crossinline create: (Repository) -> VM): ViewModelProvider.Factory =
    viewModelFactory {
        initializer {
            val app = this[APPLICATION_KEY] as HrvatskiApplication
            create(app.repository)
        }
    }

/** Small uppercase label above a group of controls. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.padding(bottom = 10.dp),
    )
}

/** Rounded selectable chip: filled when selected, outlined otherwise. */
@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(if (selected) colors.onSurface else Color.Transparent)
            .border(1.dp, if (selected) colors.onSurface else colors.outlineVariant, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) colors.surface else colors.onSurface,
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PillFlow(
    options: List<Pair<String?, String>>,
    selected: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (key, label) ->
            Pill(text = label, selected = key == selected, onClick = { onSelect(key) })
        }
    }
}

/** Two or three equally wide segments, like an iOS-style segmented control. */
@Composable
fun Segmented(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, colors.outlineVariant, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selected) colors.onSurface else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 11.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selected) colors.surface else colors.onSurface,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** Learning status as a grayscale dot: empty ring = new, ring with dot = learning, filled = known. */
@Composable
fun StatusDot(status: LearnStatus, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    when (status) {
        LearnStatus.NEW -> Box(modifier.size(10.dp).border(1.dp, colors.outline, CircleShape))
        LearnStatus.LEARNING -> Box(
            modifier.size(10.dp).border(1.dp, colors.onSurface, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.size(4.dp).background(colors.onSurface, CircleShape)) }
        LearnStatus.KNOWN -> Box(modifier.size(10.dp).background(colors.onSurface, CircleShape))
    }
}

@Composable
fun BackTopBar(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Zurück")
        }
        Text(text = title, style = MaterialTheme.typography.titleLarge, maxLines = 1)
    }
}

/** Big number with a caption underneath, used for counters. */
@Composable
fun StatBlock(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, style = MaterialTheme.typography.displaySmall)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

/** Turns "**bold**" markup into an AnnotatedString. */
fun richText(text: String): AnnotatedString = buildAnnotatedString {
    val parts = text.split("**")
    parts.forEachIndexed { index, part ->
        if (index % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(part) } else append(part)
    }
}

/** Human-readable gender label for the word list and cards. */
fun genderLabel(code: String?): String? = when (code) {
    "m" -> "maskulin"
    "f" -> "feminin"
    "n" -> "neutrum"
    "pl m" -> "Plural, maskulin"
    "pl f" -> "Plural, feminin"
    "pl n" -> "Plural, neutrum"
    else -> null
}

fun shortGender(code: String?): String? = when (code) {
    null -> null
    else -> code.replace("pl ", "Pl. ")
}
