package de.lern.hrvatski.ui.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.data.db.CategoryEntity
import de.lern.hrvatski.data.db.WordEntity
import de.lern.hrvatski.domain.LearnStatus
import de.lern.hrvatski.domain.Leitner
import de.lern.hrvatski.domain.TextNormalizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

data class WordRow(val word: WordEntity, val status: LearnStatus)
data class CategoryGroup(val category: CategoryEntity, val rows: List<WordRow>)

data class ListFilters(
    val query: String = "",
    val category: String? = null,
    val status: LearnStatus? = null,
    val collapsed: Set<String> = emptySet(),
)

class ListViewModel(repo: Repository) : ViewModel() {

    private val _filters = MutableStateFlow(ListFilters())
    val filters: StateFlow<ListFilters> = _filters.asStateFlow()

    val categories: StateFlow<List<CategoryEntity>> =
        repo.categories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Precomputed diacritic-free search keys, so typing stays fast. */
    private val searchable = repo.words.map { words ->
        words.map { it to TextNormalizer.fold("${it.german} ${it.croatian}") }
    }

    val groups: StateFlow<List<CategoryGroup>> = combine(
        repo.categories, searchable, repo.progress, _filters,
    ) { categories, words, progress, f ->
        val query = TextNormalizer.fold(f.query)
        val rows = words
            .asSequence()
            .filter { (w, _) -> f.category == null || w.categoryId == f.category }
            .filter { (_, key) -> query.isEmpty() || key.contains(query) }
            .map { (w, _) -> WordRow(w, Leitner.status(progress[w.id]?.box)) }
            .filter { f.status == null || it.status == f.status }
            .toList()
        val byCategory = rows.groupBy { it.word.categoryId }
        categories.mapNotNull { c -> byCategory[c.id]?.let { CategoryGroup(c, it) } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(q: String) = _filters.update { it.copy(query = q) }
    fun setCategory(id: String?) = _filters.update { it.copy(category = id) }
    fun setStatus(status: LearnStatus?) = _filters.update { it.copy(status = status) }
    fun toggle(categoryId: String) = _filters.update {
        it.copy(collapsed = if (categoryId in it.collapsed) it.collapsed - categoryId else it.collapsed + categoryId)
    }
}
