package de.lern.hrvatski.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.FormatListBulleted
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import de.lern.hrvatski.HrvatskiApplication
import de.lern.hrvatski.domain.Stats
import de.lern.hrvatski.ui.cards.CardsScreen
import de.lern.hrvatski.ui.common.Hairline
import de.lern.hrvatski.ui.grammar.GrammarListScreen
import de.lern.hrvatski.ui.grammar.LessonScreen
import de.lern.hrvatski.ui.list.ListScreen
import de.lern.hrvatski.ui.practice.PracticeScreen
import de.lern.hrvatski.ui.settings.SettingsScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Cards("cards", "Karten", Icons.Outlined.Style),
    Words("list", "Liste", Icons.AutoMirrored.Outlined.FormatListBulleted),
    Practice("practice", "Üben", Icons.Outlined.EditNote),
    Grammar("grammar", "Grammatik", Icons.AutoMirrored.Outlined.MenuBook),
}

@Composable
fun AppRoot() {
    val repo = (LocalContext.current.applicationContext as HrvatskiApplication).repository
    val stats by repo.stats.collectAsStateWithLifecycle(initialValue = Stats())
    val ready by repo.contentReady.collectAsStateWithLifecycle()
    val error by repo.contentError.collectAsStateWithLifecycle()

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val isTopLevel = route == null || Tab.entries.any { it.route == route }
    // Header and tabs only once the NavHost exists (navigating before that would crash).
    val showChrome = ready && error == null && isTopLevel

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (showChrome) Header(stats, onSettings = { nav.navigate("settings") })
        },
        bottomBar = {
            if (showChrome) {
                Column {
                    Hairline()
                    NavigationBar(containerColor = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                        Tab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = route == tab.route,
                                onClick = {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = null) },
                                label = { Text(tab.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.surface,
                                    selectedTextColor = MaterialTheme.colorScheme.onSurface,
                                    indicatorColor = MaterialTheme.colorScheme.onSurface,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                            )
                        }
                    }
                }
            }
        },
    ) { padding ->
        when {
            error != null -> Box(Modifier.fillMaxSize().padding(padding).padding(24.dp)) {
                Text(
                    "Die Inhalte konnten nicht geladen werden:\n\n$error\n\nBitte prüfe assets/content/vocabulary.json.",
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
            !ready -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onSurface)
            }
            else -> NavHost(
                navController = nav,
                startDestination = Tab.Cards.route,
                modifier = Modifier.padding(padding),
            ) {
                composable(Tab.Cards.route) { CardsScreen() }
                composable(Tab.Words.route) { ListScreen() }
                composable(Tab.Practice.route) { PracticeScreen() }
                composable(Tab.Grammar.route) { GrammarListScreen(onOpen = { id -> nav.navigate("lesson/$id") }) }
                composable(
                    route = "lesson/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.StringType }),
                ) { entry ->
                    LessonScreen(lessonId = entry.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() })
                }
                composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
            }
        }
    }
}

@Composable
private fun Header(stats: Stats, onSettings: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 24.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Hrvatski", style = MaterialTheme.typography.headlineMedium)
            Text(
                "${stats.streak} ${if (stats.streak == 1) "Tag" else "Tage"} in Folge · ${stats.learned} Wörter gelernt",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Einstellungen") }
    }
}
