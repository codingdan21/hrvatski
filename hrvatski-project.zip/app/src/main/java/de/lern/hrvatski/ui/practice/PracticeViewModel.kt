package de.lern.hrvatski.ui.practice

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.data.db.CategoryEntity
import de.lern.hrvatski.data.db.SentenceEntity
import de.lern.hrvatski.domain.AnswerChecker
import de.lern.hrvatski.domain.CheckResult
import de.lern.hrvatski.domain.Verdict
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class PracticeMode { TYPE, CHOICE }

data class Question(
    val sentence: SentenceEntity,
    /** Shuffled options for multiple-choice mode (answer + distractors). */
    val options: List<String>,
)

data class PracticeUiState(
    val categories: List<CategoryEntity> = emptyList(),
    val sentenceCounts: Map<String, Int> = emptyMap(),
    val selectedCategory: String? = null,
    val mode: PracticeMode = PracticeMode.TYPE,
    val lenient: Boolean = false,
    // Running session (null = setup screen)
    val questions: List<Question>? = null,
    val index: Int = 0,
    val input: TextFieldValue = TextFieldValue(""),
    val chosenOption: String? = null,
    val result: CheckResult? = null,
    val correct: Int = 0,
    val almost: Int = 0,
) {
    val current: Question? get() = questions?.getOrNull(index)
    val finished: Boolean get() = questions != null && index >= questions.size
    val availableCount: Int get() = if (selectedCategory == null) sentenceCounts.values.sum() else sentenceCounts[selectedCategory] ?: 0
}

class PracticeViewModel(private val repo: Repository) : ViewModel() {

    private val _state = MutableStateFlow(PracticeUiState())
    val state: StateFlow<PracticeUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.categories.collect { cats ->
                val counts = repo.getSentences().groupingBy { it.categoryId }.eachCount()
                _state.update { it.copy(categories = cats.filter { c -> (counts[c.id] ?: 0) > 0 }, sentenceCounts = counts) }
            }
        }
        viewModelScope.launch {
            repo.settings.collect { s -> _state.update { it.copy(lenient = s.lenient) } }
        }
    }

    fun selectCategory(id: String?) = _state.update { it.copy(selectedCategory = id) }
    fun setMode(mode: PracticeMode) = _state.update { it.copy(mode = mode) }
    fun setLenient(enabled: Boolean) {
        viewModelScope.launch { repo.setLenient(enabled) }
    }

    fun start() {
        viewModelScope.launch {
            val category = _state.value.selectedCategory
            val questions = repo.getSentences()
                .filter { category == null || it.categoryId == category }
                .shuffled()
                .take(ROUND_SIZE)
                .map { s -> Question(s, (s.distractors + s.answer).distinct().shuffled()) }
            if (questions.isEmpty()) return@launch
            _state.update {
                it.copy(
                    questions = questions, index = 0, input = TextFieldValue(""), chosenOption = null,
                    result = null, correct = 0, almost = 0,
                )
            }
        }
    }

    fun onInput(value: TextFieldValue) {
        if (_state.value.result == null) _state.update { it.copy(input = value) }
    }

    /** Inserts a Croatian special character at the cursor (for keyboards without č, ć, đ, š, ž). */
    fun insertChar(c: String) {
        val s = _state.value
        if (s.result != null) return
        val v = s.input
        val start = minOf(v.selection.start, v.selection.end)
        val end = maxOf(v.selection.start, v.selection.end)
        val text = v.text.replaceRange(start, end, c)
        _state.update { it.copy(input = TextFieldValue(text, TextRange(start + c.length))) }
    }

    fun submitTyped() {
        val s = _state.value
        val q = s.current ?: return
        if (s.result != null || s.input.text.isBlank()) return
        val result = AnswerChecker.check(s.input.text, listOf(q.sentence.answer) + q.sentence.alternatives, s.lenient)
        applyResult(q, result, chosen = null)
    }

    fun choose(option: String) {
        val s = _state.value
        val q = s.current ?: return
        if (s.result != null) return
        val verdict = if (option == q.sentence.answer || option in q.sentence.alternatives) Verdict.CORRECT else Verdict.WRONG
        applyResult(q, CheckResult(verdict, diacriticsOnly = false), chosen = option)
    }

    private fun applyResult(q: Question, result: CheckResult, chosen: String?) {
        _state.update {
            it.copy(
                result = result,
                chosenOption = chosen,
                correct = it.correct + if (result.verdict == Verdict.CORRECT) 1 else 0,
                almost = it.almost + if (result.verdict == Verdict.ALMOST) 1 else 0,
            )
        }
        viewModelScope.launch {
            val wordId = q.sentence.wordId
            // Wrong answers feed back into spaced repetition: the word becomes due again.
            if (result.verdict == Verdict.WRONG && wordId != null) repo.markWordDifficult(wordId) else repo.recordActivity()
        }
    }

    fun next() = _state.update {
        it.copy(index = it.index + 1, input = TextFieldValue(""), chosenOption = null, result = null)
    }

    fun exit() = _state.update { it.copy(questions = null) }

    companion object {
        const val ROUND_SIZE = 10
    }
}
