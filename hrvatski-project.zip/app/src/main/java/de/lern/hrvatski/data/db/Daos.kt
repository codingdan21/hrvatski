package de.lern.hrvatski.data.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ContentDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder")
    fun observeCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM words ORDER BY sortOrder")
    fun observeWords(): Flow<List<WordEntity>>

    @Query("SELECT COUNT(*) FROM sentences")
    fun observeSentenceCount(): Flow<Int>

    @Query("SELECT * FROM words ORDER BY sortOrder")
    suspend fun getWords(): List<WordEntity>

    @Query("SELECT * FROM sentences ORDER BY sortOrder")
    suspend fun getSentences(): List<SentenceEntity>

    @Query("SELECT id FROM categories")
    suspend fun categoryIds(): List<String>

    @Query("SELECT id FROM words")
    suspend fun wordIds(): List<String>

    @Query("SELECT id FROM sentences")
    suspend fun sentenceIds(): List<String>

    @Upsert
    suspend fun upsertCategories(items: List<CategoryEntity>)

    @Upsert
    suspend fun upsertWords(items: List<WordEntity>)

    @Upsert
    suspend fun upsertSentences(items: List<SentenceEntity>)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteCategory(id: String)

    @Query("DELETE FROM words WHERE id = :id")
    suspend fun deleteWord(id: String)

    @Query("DELETE FROM sentences WHERE id = :id")
    suspend fun deleteSentence(id: String)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM progress")
    fun observeProgress(): Flow<List<ProgressEntity>>

    @Query("SELECT * FROM progress")
    suspend fun getAllProgress(): List<ProgressEntity>

    @Query("SELECT * FROM progress WHERE wordId = :wordId")
    suspend fun getProgressFor(wordId: String): ProgressEntity?

    @Upsert
    suspend fun upsertProgress(item: ProgressEntity)

    @Query("DELETE FROM progress WHERE wordId = :wordId")
    suspend fun deleteProgressFor(wordId: String)

    @Query("SELECT * FROM lesson_progress")
    fun observeLessons(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId")
    suspend fun getLesson(lessonId: String): LessonProgressEntity?

    @Upsert
    suspend fun upsertLesson(item: LessonProgressEntity)

    @Query("SELECT * FROM activity")
    fun observeActivity(): Flow<List<ActivityDayEntity>>

    @Query("SELECT * FROM activity WHERE epochDay = :day")
    suspend fun getActivity(day: Long): ActivityDayEntity?

    @Upsert
    suspend fun upsertActivity(item: ActivityDayEntity)

    @Query("SELECT * FROM settings")
    fun observeSettings(): Flow<List<SettingEntity>>

    @Query("SELECT value FROM settings WHERE name = :name")
    suspend fun getSetting(name: String): String?

    @Upsert
    suspend fun putSetting(item: SettingEntity)

    @Query("DELETE FROM progress")
    suspend fun clearProgress()

    @Query("DELETE FROM lesson_progress")
    suspend fun clearLessons()

    @Query("DELETE FROM activity")
    suspend fun clearActivity()
}
