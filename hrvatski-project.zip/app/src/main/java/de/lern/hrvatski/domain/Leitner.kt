package de.lern.hrvatski.domain

enum class LearnStatus { NEW, LEARNING, KNOWN }

/**
 * Simple Leitner-box spaced repetition.
 *
 * Box 0 = never seen. Each correct answer moves a word one box up, a wrong answer sends it
 * back to box 1. The box decides when the word is due again:
 *
 *   box 1 → immediately, 2 → 1 day, 3 → 3 days, 4 → 7 days, 5 → 14 days
 *
 * A word counts as "known" from box 3 on (answered correctly at least three times, with gaps).
 */
object Leitner {
    const val MAX_BOX = 5
    const val KNOWN_BOX = 3
    const val DAY_MS = 24L * 60 * 60 * 1000
    private val intervalDays = intArrayOf(0, 0, 1, 3, 7, 14)

    fun nextBox(currentBox: Int, correct: Boolean): Int =
        if (correct) (currentBox + 1).coerceIn(1, MAX_BOX) else 1

    fun dueAt(box: Int, now: Long): Long = now + intervalDays[box.coerceIn(0, MAX_BOX)] * DAY_MS

    fun status(box: Int?): LearnStatus = when {
        box == null || box <= 0 -> LearnStatus.NEW
        box < KNOWN_BOX -> LearnStatus.LEARNING
        else -> LearnStatus.KNOWN
    }
}
