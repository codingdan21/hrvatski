package de.lern.hrvatski.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

class Converters {
    private val listSerializer = ListSerializer(String.serializer())

    @TypeConverter
    fun fromList(value: List<String>): String = Json.encodeToString(listSerializer, value)

    @TypeConverter
    fun toList(value: String): List<String> = Json.decodeFromString(listSerializer, value)
}

@Database(
    entities = [
        CategoryEntity::class,
        WordEntity::class,
        SentenceEntity::class,
        ProgressEntity::class,
        LessonProgressEntity::class,
        ActivityDayEntity::class,
        SettingEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contentDao(): ContentDao
    abstract fun userDao(): UserDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "hrvatski.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
