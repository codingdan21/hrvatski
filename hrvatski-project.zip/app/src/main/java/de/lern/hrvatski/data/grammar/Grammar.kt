package de.lern.hrvatski.data.grammar

import android.content.Context
import de.lern.hrvatski.data.seed.AppJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable

/** Shape of assets/content/grammar.json. */
@Serializable
data class GrammarFile(val lessons: List<Lesson>)

@Serializable
data class Lesson(
    val id: String,
    val number: Int,
    val title: String,
    val subtitle: String = "",
    val sections: List<LessonSection>,
    val quiz: List<QuizQuestion> = emptyList(),
)

/** A block of lesson content. Every field is optional; `text` may contain **bold** markup. */
@Serializable
data class LessonSection(
    val heading: String? = null,
    val text: String? = null,
    val table: LessonTable? = null,
    val examples: List<Example> = emptyList(),
    val tip: String? = null,
)

@Serializable
data class LessonTable(
    val headers: List<String>,
    val rows: List<List<String>>,
)

@Serializable
data class Example(val hr: String, val de: String)

@Serializable
data class QuizQuestion(
    val question: String,
    val options: List<String>,
    /** Index into [options]. */
    val answer: Int,
    val explanation: String = "",
)

/** Grammar lessons are static, so they are read straight from assets (not stored in Room). */
class GrammarSource(private val context: Context) {
    private val mutex = Mutex()
    private var cache: List<Lesson>? = null

    suspend fun lessons(): List<Lesson> = mutex.withLock {
        cache ?: withContext(Dispatchers.IO) {
            val raw = context.assets.open("content/grammar.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            AppJson.decodeFromString(GrammarFile.serializer(), raw).lessons.sortedBy { it.number }
        }.also { cache = it }
    }
}
