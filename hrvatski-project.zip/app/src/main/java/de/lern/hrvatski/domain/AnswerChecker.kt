package de.lern.hrvatski.domain

enum class Verdict { CORRECT, ALMOST, WRONG }

/**
 * @property diacriticsOnly true when the answer would be right if only the diacritics were
 * correct (e.g. "jabuku" typed correctly, but "cevapi" instead of "ćevapi").
 */
data class CheckResult(val verdict: Verdict, val diacriticsOnly: Boolean)

object AnswerChecker {

    /**
     * Compares [input] with every accepted spelling.
     * Exact match (ignoring case, spaces and surrounding punctuation) → CORRECT.
     * Match only after removing diacritics → ALMOST in lenient mode, otherwise WRONG
     * (but flagged with diacriticsOnly so the UI can explain what went wrong).
     */
    fun check(input: String, accepted: List<String>, lenient: Boolean): CheckResult {
        val normalizedInput = TextNormalizer.normalize(input)
        if (normalizedInput.isEmpty()) return CheckResult(Verdict.WRONG, diacriticsOnly = false)

        if (accepted.any { TextNormalizer.normalize(it) == normalizedInput }) {
            return CheckResult(Verdict.CORRECT, diacriticsOnly = false)
        }

        val foldedInput = TextNormalizer.fold(input)
        val matchesWithoutDiacritics = accepted.any { TextNormalizer.fold(it) == foldedInput }
        return when {
            matchesWithoutDiacritics && lenient -> CheckResult(Verdict.ALMOST, diacriticsOnly = true)
            matchesWithoutDiacritics -> CheckResult(Verdict.WRONG, diacriticsOnly = true)
            else -> CheckResult(Verdict.WRONG, diacriticsOnly = false)
        }
    }
}
