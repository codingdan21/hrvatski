package de.lern.hrvatski.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.domain.AppSettings
import de.lern.hrvatski.domain.Direction
import de.lern.hrvatski.domain.ThemeMode
import de.lern.hrvatski.ui.common.BackTopBar
import de.lern.hrvatski.ui.common.SectionLabel
import de.lern.hrvatski.ui.common.Segmented
import de.lern.hrvatski.ui.common.repoFactory
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ContentInfo(val words: Int = 0, val sentences: Int = 0, val lessons: Int = 0)

class SettingsViewModel(private val repo: Repository) : ViewModel() {
    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val info: StateFlow<ContentInfo> = combine(repo.words, repo.sentenceCount) { words, sentences ->
        ContentInfo(words.size, sentences, repo.lessons().size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ContentInfo())

    fun setTheme(mode: ThemeMode) = viewModelScope.launch { repo.setTheme(mode) }
    fun setDirection(direction: Direction) = viewModelScope.launch { repo.setDirection(direction) }
    fun setLenient(enabled: Boolean) = viewModelScope.launch { repo.setLenient(enabled) }
    fun reset() = viewModelScope.launch { repo.resetProgress() }
}

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    vm: SettingsViewModel = viewModel(factory = repoFactory { SettingsViewModel(it) }),
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val info by vm.info.collectAsStateWithLifecycle()
    var confirmReset by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        BackTopBar("Einstellungen", onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp),
        ) {
            SectionLabel("Darstellung")
            Segmented(
                options = listOf("System", "Hell", "Dunkel"),
                selectedIndex = settings.theme.ordinal,
                onSelect = { vm.setTheme(ThemeMode.entries[it]) },
            )

            Spacer(Modifier.height(28.dp))
            SectionLabel("Karteikarten – Standardrichtung")
            Segmented(
                options = listOf("Deutsch → Kroatisch", "Kroatisch → Deutsch"),
                selectedIndex = settings.defaultDirection.ordinal,
                onSelect = { vm.setDirection(Direction.entries[it]) },
            )

            Spacer(Modifier.height(28.dp))
            SectionLabel("Lückentext")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Nachsichtiger Modus", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Fehlende Sonderzeichen (č, ć, đ, š, ž) gelten als „fast richtig“ statt als Fehler.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = settings.lenient, onCheckedChange = { vm.setLenient(it) })
            }

            Spacer(Modifier.height(28.dp))
            SectionLabel("Fortschritt")
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Fortschritt zurücksetzen")
            }

            Spacer(Modifier.height(28.dp))
            SectionLabel("Inhalt")
            Text(
                "${info.words} Wörter · ${info.sentences} Lückensätze · ${info.lessons} Grammatiklektionen",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Alles offline, ohne Konto, ohne Werbung, ohne Tracking.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp),
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Fortschritt zurücksetzen?") },
            text = { Text("Alle Lernstände, Quiz-Ergebnisse und die Serie werden gelöscht. Die Wörter selbst bleiben erhalten.") },
            confirmButton = {
                TextButton(onClick = { vm.reset(); confirmReset = false }) { Text("Zurücksetzen") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Abbrechen") }
            },
        )
    }
}
