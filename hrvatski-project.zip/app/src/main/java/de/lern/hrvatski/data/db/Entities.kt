package de.lern.hrvatski.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/* ---------- Content (re-synced from assets/content/vocabulary.json) ---------- */

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val nameDe: String,
    val nameHr: String,
    val sortOrder: Int,
)

@Entity(tableName = "words", indices = [Index("categoryId")])
data class WordEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val german: String,
    val croatian: String,
    /** "m", "f", "n", "pl m", "pl f", "pl n" or null for non-nouns. */
    val gender: String?,
    /** Extra grammar info, e.g. present tense forms of a verb. */
    val info: String?,
    val exampleDe: String?,
    val exampleHr: String?,
    val sortOrder: Int,
)

@Entity(tableName = "sentences", indices = [Index("categoryId")])
data class SentenceEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    /** Linked vocabulary word: a wrong answer sends this word back to Leitner box 1. */
    val wordId: String?,
    /** Croatian sentence; "___" marks the gap. */
    val text: String,
    val answer: String,
    val alternatives: List<String>,
    /** Wrong options for multiple-choice mode (usually other case forms of the same word). */
    val distractors: List<String>,
    /** German hint shown in brackets, e.g. "der Apfel". */
    val hint: String,
    val baseForm: String,
    /** Grammar note, e.g. "Akkusativ Sg. feminin". */
    val note: String,
    val translation: String,
    val sortOrder: Int,
)

/* ---------- User data (never overwritten by the content sync) ---------- */

@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val wordId: String,
    val box: Int,
    val dueAt: Long,
    val lastReviewed: Long,
    val correct: Int,
    val wrong: Int,
)

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val completed: Boolean,
    val bestScore: Int,
    val total: Int,
)

/** One row per day with at least one review; used for the streak. */
@Entity(tableName = "activity")
data class ActivityDayEntity(
    @PrimaryKey val epochDay: Long,
    val reviews: Int,
)

/** Simple key-value store for settings and internal flags. */
@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val name: String,
    val value: String,
)
