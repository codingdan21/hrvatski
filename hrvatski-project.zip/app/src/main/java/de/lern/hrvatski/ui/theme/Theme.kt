package de.lern.hrvatski.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/*
 * Strict black & white palette. Every Material 3 color slot is set explicitly, because the
 * defaults (surfaceContainer*, secondaryContainer, error …) would otherwise leak purple/red tints.
 */

private val LightColors: ColorScheme = lightColorScheme(
    primary = Color.Black,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEAEAEA),
    onPrimaryContainer = Color.Black,
    inversePrimary = Color.White,
    secondary = Color(0xFF3D3D3D),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEAEAEA),
    onSecondaryContainer = Color.Black,
    tertiary = Color(0xFF3D3D3D),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFEAEAEA),
    onTertiaryContainer = Color.Black,
    background = Color.White,
    onBackground = Color.Black,
    surface = Color.White,
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFF2F2F2),
    onSurfaceVariant = Color(0xFF666666),
    surfaceTint = Color.White,
    inverseSurface = Color.Black,
    inverseOnSurface = Color.White,
    error = Color.Black,
    onError = Color.White,
    errorContainer = Color(0xFFEAEAEA),
    onErrorContainer = Color.Black,
    outline = Color(0xFF9E9E9E),
    outlineVariant = Color(0xFFE2E2E2),
    scrim = Color.Black,
    surfaceBright = Color.White,
    surfaceContainer = Color(0xFFF4F4F4),
    surfaceContainerHigh = Color(0xFFEEEEEE),
    surfaceContainerHighest = Color(0xFFE6E6E6),
    surfaceContainerLow = Color(0xFFF9F9F9),
    surfaceContainerLowest = Color.White,
    surfaceDim = Color(0xFFDDDDDD),
)

private val DarkColors: ColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF262626),
    onPrimaryContainer = Color.White,
    inversePrimary = Color.Black,
    secondary = Color(0xFFCFCFCF),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF262626),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFFCFCFCF),
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF262626),
    onTertiaryContainer = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF161616),
    onSurfaceVariant = Color(0xFF9A9A9A),
    surfaceTint = Color.Black,
    inverseSurface = Color.White,
    inverseOnSurface = Color.Black,
    error = Color.White,
    onError = Color.Black,
    errorContainer = Color(0xFF262626),
    onErrorContainer = Color.White,
    outline = Color(0xFF6E6E6E),
    outlineVariant = Color(0xFF2A2A2A),
    scrim = Color.Black,
    surfaceBright = Color(0xFF2A2A2A),
    surfaceContainer = Color(0xFF111111),
    surfaceContainerHigh = Color(0xFF1A1A1A),
    surfaceContainerHighest = Color(0xFF242424),
    surfaceContainerLow = Color(0xFF0A0A0A),
    surfaceContainerLowest = Color.Black,
    surfaceDim = Color.Black,
)

private val Base = Typography()
private val Sans = FontFamily.SansSerif

private fun TextStyle.sans(weight: FontWeight? = null, tracking: Float? = null) = copy(
    fontFamily = Sans,
    fontWeight = weight ?: fontWeight,
    letterSpacing = tracking?.sp ?: letterSpacing,
)

private val AppTypography = Typography(
    displayLarge = Base.displayLarge.sans(FontWeight.Light, -1.5f),
    displayMedium = Base.displayMedium.sans(FontWeight.Light, -1f),
    displaySmall = Base.displaySmall.sans(FontWeight.Normal, -0.5f),
    headlineLarge = Base.headlineLarge.sans(FontWeight.SemiBold, -0.5f),
    headlineMedium = Base.headlineMedium.sans(FontWeight.SemiBold, -0.5f),
    headlineSmall = Base.headlineSmall.sans(FontWeight.SemiBold, -0.25f),
    titleLarge = Base.titleLarge.sans(FontWeight.SemiBold),
    titleMedium = Base.titleMedium.sans(FontWeight.Medium),
    titleSmall = Base.titleSmall.sans(FontWeight.Medium),
    bodyLarge = Base.bodyLarge.sans(),
    bodyMedium = Base.bodyMedium.sans(),
    bodySmall = Base.bodySmall.sans(),
    labelLarge = Base.labelLarge.sans(FontWeight.Medium),
    labelMedium = Base.labelMedium.sans(FontWeight.Medium),
    labelSmall = Base.labelSmall.sans(FontWeight.Medium, 1.2f),
)

@Composable
fun HrvatskiTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
