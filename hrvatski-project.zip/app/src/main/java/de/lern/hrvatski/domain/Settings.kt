package de.lern.hrvatski.domain

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class Direction { DE_TO_HR, HR_TO_DE }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val defaultDirection: Direction = Direction.DE_TO_HR,
    val lenient: Boolean = false,
)

data class Stats(
    val streak: Int = 0,
    val learned: Int = 0,
)
