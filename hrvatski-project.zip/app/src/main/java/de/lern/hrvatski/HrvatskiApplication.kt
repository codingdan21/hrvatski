package de.lern.hrvatski

import android.app.Application
import android.util.Log
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.data.db.AppDatabase
import de.lern.hrvatski.data.grammar.GrammarSource
import de.lern.hrvatski.data.seed.ContentSeeder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Holds the app-wide singletons (manual dependency injection, no framework needed). */
class HrvatskiApplication : Application() {

    lateinit var repository: Repository
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.build(this)
        repository = Repository(db, GrammarSource(this))

        appScope.launch {
            try {
                ContentSeeder(this@HrvatskiApplication, db).syncIfNeeded()
            } catch (e: Exception) {
                Log.e("Hrvatski", "Content sync failed", e)
                repository.contentError.value = e.message ?: e.toString()
            } finally {
                repository.contentReady.value = true
            }
        }
    }
}
