package de.lern.hrvatski.data

import de.lern.hrvatski.data.db.ActivityDayEntity
import de.lern.hrvatski.data.db.AppDatabase
import de.lern.hrvatski.data.db.CategoryEntity
import de.lern.hrvatski.data.db.LessonProgressEntity
import de.lern.hrvatski.data.db.ProgressEntity
import de.lern.hrvatski.data.db.SentenceEntity
import de.lern.hrvatski.data.db.SettingEntity
import de.lern.hrvatski.data.db.WordEntity
import de.lern.hrvatski.data.grammar.GrammarSource
import de.lern.hrvatski.data.grammar.Lesson
import de.lern.hrvatski.domain.AppSettings
import de.lern.hrvatski.domain.Direction
import de.lern.hrvatski.domain.Leitner
import de.lern.hrvatski.domain.Stats
import de.lern.hrvatski.domain.Streak
import de.lern.hrvatski.domain.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.LocalDate

/** Single entry point for all data the UI needs. ViewModels never talk to Room directly. */
class Repository(
    private val db: AppDatabase,
    private val grammarSource: GrammarSource,
) {
    private val content = db.contentDao()
    private val user = db.userDao()

    /** Set by the application if the bundled content can't be loaded (e.g. broken JSON). */
    val contentError = MutableStateFlow<String?>(null)
    val contentReady = MutableStateFlow(false)
    val isContentReady: StateFlow<Boolean> get() = contentReady

    val categories: Flow<List<CategoryEntity>> = content.observeCategories()
    val words: Flow<List<WordEntity>> = content.observeWords()
    val sentenceCount: Flow<Int> = content.observeSentenceCount()

    val progress: Flow<Map<String, ProgressEntity>> =
        user.observeProgress().map { list -> list.associateBy { it.wordId } }

    val lessonProgress: Flow<Map<String, LessonProgressEntity>> =
        user.observeLessons().map { list -> list.associateBy { it.lessonId } }

    val settings: Flow<AppSettings> = user.observeSettings().map { rows ->
        val map = rows.associate { it.name to it.value }
        AppSettings(
            theme = map[KEY_THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            defaultDirection = map[KEY_DIRECTION]?.let { runCatching { Direction.valueOf(it) }.getOrNull() }
                ?: Direction.DE_TO_HR,
            lenient = map[KEY_LENIENT]?.toBooleanStrictOrNull() ?: false,
        )
    }

    val stats: Flow<Stats> = combine(user.observeProgress(), user.observeActivity()) { progress, activity ->
        Stats(
            streak = Streak.current(activity.map { it.epochDay }.toSet(), LocalDate.now().toEpochDay()),
            learned = progress.count { it.box >= Leitner.KNOWN_BOX },
        )
    }

    suspend fun getWords(): List<WordEntity> = content.getWords()
    suspend fun getSentences(): List<SentenceEntity> = content.getSentences()
    suspend fun getProgress(): Map<String, ProgressEntity> = user.getAllProgress().associateBy { it.wordId }
    suspend fun lessons(): List<Lesson> = grammarSource.lessons()

    /** Flashcard answer: moves the word up one Leitner box, or back to box 1. */
    suspend fun reviewWord(wordId: String, correct: Boolean) {
        val now = System.currentTimeMillis()
        val old = user.getProgressFor(wordId)
        val box = Leitner.nextBox(old?.box ?: 0, correct)
        user.upsertProgress(
            ProgressEntity(
                wordId = wordId,
                box = box,
                dueAt = Leitner.dueAt(box, now),
                lastReviewed = now,
                correct = (old?.correct ?: 0) + if (correct) 1 else 0,
                wrong = (old?.wrong ?: 0) + if (correct) 0 else 1,
            )
        )
        recordActivity()
    }

    /** A wrong fill-in answer makes the linked word due again right away. */
    suspend fun markWordDifficult(wordId: String) = reviewWord(wordId, correct = false)

    suspend fun recordActivity() {
        val today = LocalDate.now().toEpochDay()
        val old = user.getActivity(today)
        user.upsertActivity(ActivityDayEntity(today, (old?.reviews ?: 0) + 1))
    }

    suspend fun saveLessonResult(lessonId: String, score: Int, total: Int) {
        val old = user.getLesson(lessonId)
        user.upsertLesson(
            LessonProgressEntity(
                lessonId = lessonId,
                completed = true,
                bestScore = maxOf(score, old?.bestScore ?: 0),
                total = total,
            )
        )
        recordActivity()
    }

    suspend fun setTheme(mode: ThemeMode) = user.putSetting(SettingEntity(KEY_THEME, mode.name))
    suspend fun setDirection(direction: Direction) = user.putSetting(SettingEntity(KEY_DIRECTION, direction.name))
    suspend fun setLenient(enabled: Boolean) = user.putSetting(SettingEntity(KEY_LENIENT, enabled.toString()))

    suspend fun resetProgress() {
        user.clearProgress()
        user.clearLessons()
        user.clearActivity()
    }

    private companion object {
        const val KEY_THEME = "theme"
        const val KEY_DIRECTION = "direction"
        const val KEY_LENIENT = "lenient"
    }
}
