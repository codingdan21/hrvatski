package de.lern.hrvatski.ui.cards

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.lern.hrvatski.data.Repository
import de.lern.hrvatski.data.db.CategoryEntity
import de.lern.hrvatski.data.db.WordEntity
import de.lern.hrvatski.domain.Direction
import de.lern.hrvatski.domain.LearnStatus
import de.lern.hrvatski.domain.Leitner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DeckCounts(val due: Int = 0, val fresh: Int = 0, val known: Int = 0, val total: Int = 0)

data class CardSession(
    /** Remaining cards; the first one is shown. Cards answered with "again" go to the end. */
    val queue: List<WordEntity>,
    val total: Int,
    val knownCount: Int = 0,
    val reviews: Int = 0,
    val flipped: Boolean = false,
) {
    val current: WordEntity? get() = queue.firstOrNull()
    val finished: Boolean get() = queue.isEmpty()
}

data class CardsUiState(
    val categories: List<CategoryEntity> = emptyList(),
    val selectedCategory: String? = null,
    val direction: Direction = Direction.DE_TO_HR,
    val shuffle: Boolean = true,
    val session: CardSession? = null,
    val nothingDue: Boolean = false,
)

class CardsViewModel(private val repo: Repository) : ViewModel() {

    private val _state = MutableStateFlow(CardsUiState())
    val state: StateFlow<CardsUiState> = _state.asStateFlow()

    /** Due / new / known counts for the selected category, updated live. */
    val counts: StateFlow<DeckCounts> = combine(
        repo.words,
        repo.progress,
        _state.map { it.selectedCategory }.distinctUntilChanged(),
    ) { words, progress, category ->
        val now = System.currentTimeMillis()
        val inDeck = words.filter { category == null || it.categoryId == category }
        var due = 0
        var fresh = 0
        var known = 0
        inDeck.forEach { w ->
            val p = progress[w.id]
            when {
                p == null || p.box <= 0 -> fresh++
                p.dueAt <= now -> due++
            }
            if (Leitner.status(p?.box) == LearnStatus.KNOWN) known++
        }
        DeckCounts(due = due, fresh = fresh, known = known, total = inDeck.size)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DeckCounts())

    init {
        viewModelScope.launch {
            repo.categories.collect { cats -> _state.update { it.copy(categories = cats) } }
        }
        viewModelScope.launch {
            val settings = repo.settings.first()
            _state.update { it.copy(direction = settings.defaultDirection) }
        }
    }

    fun selectCategory(id: String?) = _state.update { it.copy(selectedCategory = id, nothingDue = false) }
    fun setDirection(direction: Direction) = _state.update { it.copy(direction = direction) }
    fun setShuffle(shuffle: Boolean) = _state.update { it.copy(shuffle = shuffle) }

    /**
     * Builds a session: due cards first (most overdue first), then new cards, max [SESSION_SIZE].
     * With [practiceAll] it falls back to random cards of the deck when nothing is due.
     */
    fun start(practiceAll: Boolean = false) {
        viewModelScope.launch {
            val current = _state.value
            val now = System.currentTimeMillis()
            val words = repo.getWords().filter { current.selectedCategory == null || it.categoryId == current.selectedCategory }
            val progress = repo.getProgress()

            val due = words
                .filter { w -> progress[w.id]?.let { it.box > 0 && it.dueAt <= now } == true }
                .sortedBy { progress[it.id]?.dueAt ?: 0L }
            val freshAll = words.filter { w -> (progress[w.id]?.box ?: 0) <= 0 }
            val fresh = if (current.shuffle) freshAll.shuffled() else freshAll

            var picked = (due + fresh).take(SESSION_SIZE)
            if (picked.isEmpty() && practiceAll) picked = words.shuffled().take(SESSION_SIZE)
            if (picked.isEmpty()) {
                _state.update { it.copy(nothingDue = true) }
                return@launch
            }
            if (current.shuffle) picked = picked.shuffled()
            _state.update { it.copy(session = CardSession(queue = picked, total = picked.size), nothingDue = false) }
        }
    }

    fun flip() = _state.update { s -> s.copy(session = s.session?.let { it.copy(flipped = !it.flipped) }) }

    /** knew = true: "Gewusst" (word moves up a box). false: "Nochmal" (back to box 1, card repeats). */
    fun answer(knew: Boolean) {
        val session = _state.value.session ?: return
        val word = session.current ?: return
        viewModelScope.launch { repo.reviewWord(word.id, knew) }
        val rest = session.queue.drop(1)
        _state.update {
            it.copy(
                session = session.copy(
                    queue = if (knew) rest else rest + word,
                    knownCount = session.knownCount + if (knew) 1 else 0,
                    reviews = session.reviews + 1,
                    flipped = false,
                )
            )
        }
    }

    fun endSession() = _state.update { it.copy(session = null) }

    companion object {
        const val SESSION_SIZE = 20
    }
}
