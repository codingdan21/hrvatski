package de.lern.hrvatski.ui.grammar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import de.lern.hrvatski.data.grammar.LessonSection
import de.lern.hrvatski.data.grammar.LessonTable
import de.lern.hrvatski.data.grammar.QuizQuestion
import de.lern.hrvatski.ui.common.BackTopBar
import de.lern.hrvatski.ui.common.Hairline
import de.lern.hrvatski.ui.common.SectionLabel
import de.lern.hrvatski.ui.common.repoFactory
import de.lern.hrvatski.ui.common.richText

/* ------------------------------- Lesson list ------------------------------- */

@Composable
fun GrammarListScreen(
    onOpen: (String) -> Unit,
    vm: GrammarListViewModel = viewModel(factory = repoFactory { GrammarListViewModel(it) }),
) {
    val lessons by vm.lessons.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val completed = lessons.count { progress[it.id]?.completed == true }
    val colors = MaterialTheme.colorScheme

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                Text("$completed von ${lessons.size} Lektionen abgeschlossen", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (lessons.isEmpty()) 0f else completed.toFloat() / lessons.size },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = colors.onSurface,
                    trackColor = colors.outlineVariant,
                )
                Spacer(Modifier.height(12.dp))
            }
        }
        items(lessons, key = { it.id }) { lesson ->
            val p = progress[lesson.id]
            val done = p?.completed == true
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(lesson.id) }
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (done) colors.onSurface else Color.Transparent)
                        .border(1.dp, if (done) colors.onSurface else colors.outlineVariant, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (done) {
                        Icon(Icons.Outlined.Check, contentDescription = "abgeschlossen", tint = colors.surface, modifier = Modifier.size(20.dp))
                    } else {
                        Text(lesson.number.toString(), style = MaterialTheme.typography.labelLarge)
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(lesson.title, style = MaterialTheme.typography.titleMedium)
                    if (lesson.subtitle.isNotBlank()) {
                        Text(lesson.subtitle, style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                    }
                }
                if (p != null) {
                    Text("${p.bestScore}/${p.total}", style = MaterialTheme.typography.labelLarge, color = colors.onSurfaceVariant)
                }
            }
            Hairline(Modifier.padding(start = 80.dp))
        }
    }
}

/* ------------------------------- Lesson detail ------------------------------- */

@Composable
fun LessonScreen(lessonId: String, onBack: () -> Unit) {
    val vm: LessonViewModel = viewModel(
        key = "lesson_$lessonId",
        factory = repoFactory { LessonViewModel(it, lessonId) },
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val lesson = state.lesson

    Column(Modifier.fillMaxSize()) {
        BackTopBar(title = lesson?.let { "${it.number}. ${it.title}" } ?: "", onBack = onBack)
        if (lesson == null) return@Column
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 40.dp)) {
            if (lesson.subtitle.isNotBlank()) {
                item {
                    Text(lesson.subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                }
            }
            items(lesson.sections) { section -> SectionView(section) }

            if (lesson.quiz.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(32.dp))
                    Hairline()
                    Spacer(Modifier.height(24.dp))
                    Text("Quiz", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "${lesson.quiz.size} Fragen – beantworte alle, um die Lektion abzuschließen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                itemsIndexed(lesson.quiz) { index, question ->
                    QuizItem(index, question, state.answers[index], onAnswer = { vm.answer(index, it) })
                }
                if (state.quizDone) {
                    item { QuizResult(state.score, state.quizSize, onRetry = vm::resetQuiz) }
                }
            }
        }
    }
}

@Composable
private fun SectionView(section: LessonSection) {
    val colors = MaterialTheme.colorScheme
    Column(Modifier.padding(top = 20.dp)) {
        section.heading?.let {
            Text(it, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
        }
        section.text?.let {
            Text(richText(it), style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
        }
        section.table?.let {
            Spacer(Modifier.height(4.dp))
            TableView(it)
            Spacer(Modifier.height(8.dp))
        }
        if (section.examples.isNotEmpty()) {
            Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                section.examples.forEach { ex ->
                    Row {
                        Box(Modifier.padding(top = 9.dp).size(5.dp).background(colors.onSurface, CircleShape))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(ex.hr, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                            Text(ex.de, style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, color = colors.onSurfaceVariant)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        section.tip?.let {
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, colors.outlineVariant, RoundedCornerShape(16.dp))
                    .padding(16.dp),
            ) {
                Icon(Icons.Outlined.Lightbulb, contentDescription = "Tipp", modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Text(richText(it), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

/** Simple grid table; scrolls horizontally if it is wider than the screen. */
@Composable
private fun TableView(table: LessonTable) {
    val colors = MaterialTheme.colorScheme
    val columns = table.headers.size
    val cellWidth = if (columns <= 3) 140.dp else 118.dp
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, colors.outlineVariant, RoundedCornerShape(12.dp))
            .horizontalScroll(rememberScrollState()),
    ) {
        Row(Modifier.background(colors.onSurface)) {
            table.headers.forEach { h ->
                Text(
                    h,
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.surface,
                    modifier = Modifier.widthIn(min = cellWidth, max = cellWidth * 1.6f).padding(horizontal = 12.dp, vertical = 10.dp),
                )
            }
        }
        table.rows.forEachIndexed { rowIndex, row ->
            Row(Modifier.background(if (rowIndex % 2 == 1) colors.surfaceContainer else Color.Transparent)) {
                (0 until columns).forEach { col ->
                    Text(
                        row.getOrElse(col) { "" },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (col == 0) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.widthIn(min = cellWidth, max = cellWidth * 1.6f).padding(horizontal = 12.dp, vertical = 10.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun QuizItem(index: Int, question: QuizQuestion, chosen: Int?, onAnswer: (Int) -> Unit) {
    val colors = MaterialTheme.colorScheme
    val answered = chosen != null
    Column(Modifier.padding(top = 24.dp)) {
        SectionLabel("Frage ${index + 1}")
        Text(question.question, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            question.options.forEachIndexed { i, option ->
                val isAnswer = i == question.answer
                val filled = answered && isAnswer
                val wrongPick = answered && chosen == i && !isAnswer
                val shape = RoundedCornerShape(12.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (filled) colors.onSurface else Color.Transparent)
                        .border(if (wrongPick) 2.dp else 1.dp, if (filled || wrongPick) colors.onSurface else colors.outlineVariant, shape)
                        .clickable(enabled = !answered) { onAnswer(i) }
                        .padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        option,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (filled) colors.surface else colors.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    if (filled) Icon(Icons.Outlined.Check, contentDescription = "richtig", tint = colors.surface, modifier = Modifier.size(18.dp))
                    if (wrongPick) Icon(Icons.Outlined.Close, contentDescription = "falsch", modifier = Modifier.size(18.dp))
                }
            }
        }
        if (answered && question.explanation.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(question.explanation, style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
        }
    }
}

@Composable
private fun QuizResult(score: Int, total: Int, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 32.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.onSurface)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("$score / $total", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.surface)
        Text("Lektion abgeschlossen", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.surface)
    }
    Spacer(Modifier.height(12.dp))
    OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Quiz wiederholen") }
}
