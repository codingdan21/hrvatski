package de.lern.hrvatski.ui.practice

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import de.lern.hrvatski.domain.Verdict
import de.lern.hrvatski.ui.common.PillFlow
import de.lern.hrvatski.ui.common.SectionLabel
import de.lern.hrvatski.ui.common.Segmented
import de.lern.hrvatski.ui.common.repoFactory

@Composable
fun PracticeScreen(vm: PracticeViewModel = viewModel(factory = repoFactory { PracticeViewModel(it) })) {
    val state by vm.state.collectAsStateWithLifecycle()
    when {
        state.questions == null -> PracticeSetup(state, vm)
        state.finished -> PracticeSummary(state, onAgain = vm::start, onExit = vm::exit)
        else -> QuestionView(state, vm)
    }
}

@Composable
private fun PracticeSetup(state: PracticeUiState, vm: PracticeViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 8.dp),
    ) {
        Text("Lückentext", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text(
            "Setze das kroatische Wort in der richtigen Form ein – die deutsche Grundform steht als Hinweis dabei.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(28.dp))
        SectionLabel("Kategorie")
        PillFlow(
            options = listOf<Pair<String?, String>>(null to "Alle") + state.categories.map { it.id to it.nameDe },
            selected = state.selectedCategory,
            onSelect = vm::selectCategory,
        )

        Spacer(Modifier.height(28.dp))
        SectionLabel("Modus")
        Segmented(
            options = listOf("Eintippen", "Auswahl (4)"),
            selectedIndex = if (state.mode == PracticeMode.TYPE) 0 else 1,
            onSelect = { vm.setMode(if (it == 0) PracticeMode.TYPE else PracticeMode.CHOICE) },
        )

        if (state.mode == PracticeMode.TYPE) {
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Nachsichtiger Modus", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Antworten ohne č, ć, đ, š, ž gelten als „fast richtig“.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = state.lenient, onCheckedChange = vm::setLenient)
            }
        }

        Spacer(Modifier.height(32.dp))
        Button(
            onClick = vm::start,
            enabled = state.availableCount > 0,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) { Text("Los geht's", style = MaterialTheme.typography.titleMedium) }
        Spacer(Modifier.height(12.dp))
        Text(
            "${minOf(PracticeViewModel.ROUND_SIZE, state.availableCount)} Sätze pro Runde · ${state.availableCount} verfügbar",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun QuestionView(state: PracticeUiState, vm: PracticeViewModel) {
    val q = state.current ?: return
    val total = state.questions?.size ?: 1
    val s = q.sentence
    val answered = state.result != null
    val colors = MaterialTheme.colorScheme

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::exit) { Icon(Icons.Outlined.Close, contentDescription = "Beenden") }
            LinearProgressIndicator(
                progress = { (state.index + if (answered) 1 else 0).toFloat() / total },
                modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = colors.onSurface,
                trackColor = colors.outlineVariant,
            )
            Spacer(Modifier.width(16.dp))
            Text("${state.index + 1}/$total", style = MaterialTheme.typography.labelLarge)
        }

        Spacer(Modifier.height(32.dp))
        SectionLabel("Ergänze das Wort")

        // Sentence: before answering the gap is a line, afterwards the correct answer in bold.
        val parts = s.text.split("___", limit = 2)
        Text(
            buildAnnotatedString {
                append(parts.getOrElse(0) { "" })
                if (answered) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, textDecoration = TextDecoration.Underline)) { append(s.answer) }
                } else {
                    append("______")
                }
                append(parts.getOrElse(1) { "" })
            },
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Normal),
        )
        Spacer(Modifier.height(10.dp))
        Text("(${s.hint})", style = MaterialTheme.typography.titleMedium, color = colors.onSurfaceVariant)

        Spacer(Modifier.height(28.dp))
        if (state.mode == PracticeMode.TYPE) {
            OutlinedTextField(
                value = state.input,
                onValueChange = vm::onInput,
                singleLine = true,
                enabled = !answered,
                placeholder = { Text("Antwort auf Kroatisch") },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { vm.submitTyped() }),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = colors.outlineVariant,
                    focusedBorderColor = colors.onSurface,
                    disabledTextColor = colors.onSurface,
                    disabledBorderColor = colors.outlineVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            if (!answered) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("č", "ć", "đ", "š", "ž").forEach { c ->
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, colors.outlineVariant, RoundedCornerShape(10.dp))
                                .clickable { vm.insertChar(c) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(c, style = MaterialTheme.typography.titleMedium) }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = vm::submitTyped,
                    enabled = state.input.text.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                ) { Text("Prüfen", style = MaterialTheme.typography.titleMedium) }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                q.options.forEach { option ->
                    ChoiceButton(
                        text = option,
                        isAnswer = option == s.answer,
                        isChosen = option == state.chosenOption,
                        answered = answered,
                        onClick = { vm.choose(option) },
                    )
                }
            }
        }

        state.result?.let { result ->
            Spacer(Modifier.height(24.dp))
            Feedback(state, result.verdict, result.diacriticsOnly)
            Spacer(Modifier.height(20.dp))
            Button(onClick = vm::next, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text(if (state.index + 1 >= total) "Ergebnis" else "Weiter", style = MaterialTheme.typography.titleMedium)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ChoiceButton(text: String, isAnswer: Boolean, isChosen: Boolean, answered: Boolean, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(14.dp)
    val filled = answered && isAnswer
    val wrongPick = answered && isChosen && !isAnswer
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (filled) colors.onSurface else Color.Transparent)
            .border(if (wrongPick) 2.dp else 1.dp, if (filled || wrongPick) colors.onSurface else colors.outlineVariant, shape)
            .clickable(enabled = !answered, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.titleMedium,
            color = if (filled) colors.surface else colors.onSurface,
            textDecoration = if (wrongPick) TextDecoration.LineThrough else null,
            modifier = Modifier.weight(1f),
        )
        if (filled) Icon(Icons.Outlined.Check, contentDescription = "richtig", tint = colors.surface)
        if (wrongPick) Icon(Icons.Outlined.Close, contentDescription = "falsch", tint = colors.onSurface)
    }
}

@Composable
private fun Feedback(state: PracticeUiState, verdict: Verdict, diacriticsOnly: Boolean) {
    val s = state.current?.sentence ?: return
    val colors = MaterialTheme.colorScheme
    val (icon, title) = when (verdict) {
        Verdict.CORRECT -> Icons.Outlined.Check to "Richtig!"
        Verdict.ALMOST -> Icons.Outlined.ErrorOutline to "Fast richtig – achte auf die Sonderzeichen"
        Verdict.WRONG -> Icons.Outlined.Close to
            (if (diacriticsOnly) "Leider falsch – nur die Sonderzeichen fehlen" else "Leider falsch")
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surfaceContainerHigh)
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
        if (verdict != Verdict.CORRECT) {
            Spacer(Modifier.height(12.dp))
            Text(
                buildAnnotatedString {
                    append("Richtige Antwort: ")
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.answer) }
                },
                style = MaterialTheme.typography.bodyLarge,
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(s.text.replace("___", s.answer), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        if (s.translation.isNotBlank()) {
            Text(s.translation, style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
        Text(
            buildAnnotatedString {
                append("Grundform: ")
                withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(s.baseForm) }
            },
            style = MaterialTheme.typography.bodyMedium,
        )
        if (s.note.isNotBlank()) {
            Text(s.note, style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
        }
    }
}

@Composable
private fun PracticeSummary(state: PracticeUiState, onAgain: () -> Unit, onExit: () -> Unit) {
    val total = state.questions?.size ?: 0
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("${state.correct} / $total", style = MaterialTheme.typography.displayLarge)
        Text("richtig", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (state.almost > 0) {
            Spacer(Modifier.height(8.dp))
            Text(
                "+ ${state.almost} fast richtig (Sonderzeichen)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Falsch beantwortete Wörter erscheinen wieder bei den Karteikarten.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(40.dp))
        Button(onClick = onAgain, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Neue Runde") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Andere Kategorie") }
    }
}
