#!/usr/bin/env python3
"""
Generates app/src/main/assets/content/grammar.json (grammar lessons in German).
You can also edit the JSON directly. Run:  python3 tools/build_grammar.py

Section text may use **bold**. In quiz questions, "answer" is the index of the correct option.
"""
import json
import os

LESSONS = []


def lesson(lid, title, subtitle, sections, quiz):
    LESSONS.append(dict(id=lid, number=len(LESSONS) + 1, title=title, subtitle=subtitle,
                        sections=sections, quiz=quiz))


def sec(heading=None, text=None, table=None, examples=(), tip=None):
    d = {}
    if heading:
        d["heading"] = heading
    if text:
        d["text"] = text
    if table:
        d["table"] = {"headers": table[0], "rows": table[1:]}
    if examples:
        d["examples"] = [{"hr": hr, "de": de} for hr, de in examples]
    if tip:
        d["tip"] = tip
    return d


def Q(question, options, answer, explanation=""):
    assert 0 <= answer < len(options)
    return dict(question=question, options=options, answer=answer, explanation=explanation)


# ---------------------------------------------------------------------------------------------
lesson("alphabet", "Alphabet & Aussprache", "30 Buchstaben – jeder wird gesprochen", [
    sec(text="Kroatisch wird **so geschrieben, wie es gesprochen wird**: Jeder Buchstabe steht für genau "
             "einen Laut, und es gibt keine stummen Buchstaben. Das Alphabet hat 30 Buchstaben – drei davon "
             "(dž, lj, nj) werden mit zwei Zeichen geschrieben, zählen aber als ein Buchstabe."),
    sec("Das Alphabet",
        text="A B C Č Ć D Dž Đ E F G H I J K L Lj M N Nj O P R S Š T U V Z Ž"),
    sec("Laute, die anders sind als im Deutschen",
        table=[["Buchstabe", "Aussprache", "Beispiel"],
               ["c", "wie „z“ in Zug", "cesta (Straße)"],
               ["č", "hartes „tsch“ wie in Tschechien", "čaj (Tee)"],
               ["ć", "weiches „tsch“, Zunge weiter vorne (fast „tj“)", "kuća (Haus)"],
               ["dž", "hartes „dsch“ wie in Dschungel", "džep (Tasche)"],
               ["đ", "weiches „dsch“ (fast „dj“)", "đak (Schüler)"],
               ["š", "wie „sch“", "šuma (Wald)"],
               ["ž", "stimmhaftes „sch“ wie in Journal", "žena (Frau)"],
               ["z", "stimmhaftes „s“ wie in Sonne", "zima (Winter)"],
               ["s", "immer stimmloses „s“ wie in Haus", "sok (Saft)"],
               ["v", "wie deutsches „w“", "voda (Wasser)"],
               ["h", "wie „ch“ in Bach", "hvala (danke)"],
               ["j", "wie deutsches „j“", "jaje (Ei)"],
               ["lj", "wie „lj“ in einem Laut (vgl. ital. „gli“)", "ljubav (Liebe)"],
               ["nj", "wie „gn“ in Champagner", "konj (Pferd)"],
               ["r", "gerolltes Zungen-r", "riba (Fisch)"]]),
    sec("Das r als Vokal",
        text="Zwischen Konsonanten kann **r** die Rolle eines Vokals übernehmen und eine eigene Silbe bilden. "
             "Deshalb sind Wörter wie trg oder prst gar nicht so schwer, wie sie aussehen.",
        examples=[("trg", "Platz (eine Silbe: t-r-g)"), ("prst", "Finger"), ("Hrvatska", "Kroatien – Hr-vat-ska")]),
    sec("Betonung",
        text="Die Betonung liegt **nie auf der letzten Silbe** eines mehrsilbigen Wortes. Kroatisch hat außerdem "
             "steigende und fallende Töne – für den Anfang reicht es, die Wörter oft zu hören und nachzusprechen.",
        tip="č und ć klingen für deutsche Ohren fast gleich. Wenn du unsicher bist, schau dir die Schreibung an: "
            "Verwechslungen fallen im Gespräch kaum auf, in der Schrift aber schon."),
], [
    Q("Wie wird „c“ in „cesta“ ausgesprochen?", ["wie „k“", "wie „z“ in Zug", "wie „tsch“", "wie „s“"], 1,
      "c klingt immer wie deutsches z (ts)."),
    Q("Welcher Laut ist das weiche „tsch“?", ["č", "ć", "dž", "š"], 1,
      "ć ist weich (Zunge vorne), č ist hart."),
    Q("Wie viele Silben hat „trg“?", ["keine", "eine", "zwei", "drei"], 1,
      "Das r bildet hier den Silbenkern: eine Silbe."),
    Q("Wie spricht man „ž“ in „žena“?", ["wie „s“ in Haus", "wie „z“ in Zug", "wie „j“ in Journal", "wie „sch“ in Schule"], 2,
      "ž ist das stimmhafte sch – wie das j in Journal."),
    Q("Wie viele Buchstaben hat das kroatische Alphabet?", ["26", "28", "30", "32"], 2,
      "30 Buchstaben, inklusive dž, lj und nj."),
])

# ---------------------------------------------------------------------------------------------
lesson("pronouns_biti", "Personalpronomen & „biti“", "ich, du, er … und das Verb „sein“", [
    sec("Personalpronomen",
        table=[["", "Singular", "Plural"],
               ["1. Person", "ja – ich", "mi – wir"],
               ["2. Person", "ti – du", "vi – ihr / Sie"],
               ["3. Person", "on – er, ona – sie, ono – es", "oni – sie (m), one – sie (f), ona – sie (n)"]]),
    sec(text="Da die Verbendung die Person schon zeigt, wird das Pronomen **meist weggelassen**: "
             "„Umoran sam“ statt „Ja sam umoran“. Das Pronomen steht nur zur Betonung."),
    sec("Höflichkeitsform",
        text="Gesiezt wird mit **vi** (2. Person Plural) – wie das deutsche „Sie“, nur in der 2. statt 3. Person.",
        examples=[("Kako ste?", "Wie geht es Ihnen?"), ("Kako si?", "Wie geht es dir?")]),
    sec("Das Verb biti (sein) im Präsens",
        text="biti hat eine unbetonte Kurzform (am häufigsten), eine betonte Langform (für Betonung, Kurzantworten "
             "und Fragen) und eine eigene verneinte Form.",
        table=[["Person", "Kurzform", "Langform", "verneint"],
               ["ja", "sam", "jesam", "nisam"],
               ["ti", "si", "jesi", "nisi"],
               ["on/ona/ono", "je", "jest", "nije"],
               ["mi", "smo", "jesmo", "nismo"],
               ["vi", "ste", "jeste", "niste"],
               ["oni/one/ona", "su", "jesu", "nisu"]]),
    sec("Beispiele",
        examples=[("Ja sam Daniel.", "Ich bin Daniel."), ("Student sam.", "Ich bin Student."),
                  ("Jesi li umoran?", "Bist du müde?"), ("Jesam.", "Ja, bin ich."),
                  ("Nismo kod kuće.", "Wir sind nicht zu Hause.")],
        tip="Die Kurzformen (sam, si, je …) dürfen nie am Satzanfang stehen. Man sagt „Student sam“ oder "
            "„Ja sam student“, aber nie „Sam student“."),
], [
    Q("Wie sagt man „wir sind“?", ["mi su", "mi smo", "mi ste", "mi jesu"], 1),
    Q("Was ist die verneinte Form von „je“?", ["ne je", "nisu", "nije", "nismo"], 2,
      "biti hat eigene verneinte Formen: nisam, nisi, nije …"),
    Q("Welcher Satz ist richtig?", ["Sam umoran.", "Umoran sam.", "Sam ja umoran.", "Umoran jesam ja."], 1,
      "Die Kurzform sam darf nicht am Satzanfang stehen."),
    Q("Wie siezt man jemanden?", ["mit ti", "mit oni", "mit vi", "mit on"], 2),
    Q("„Jesi li gladan?“ – kurze Antwort „Ja.“:", ["Sam.", "Jesam.", "Je.", "Jesi."], 1,
      "In Kurzantworten steht die Langform."),
])

# ---------------------------------------------------------------------------------------------
lesson("gender", "Das Geschlecht der Nomen", "maskulin, feminin, neutrum – meist an der Endung erkennbar", [
    sec(text="Wie im Deutschen gibt es drei Geschlechter. Es gibt **keine Artikel** – das Geschlecht erkennt man "
             "fast immer an der Endung im Nominativ Singular."),
    sec("Die Grundregel",
        table=[["Geschlecht", "typische Endung", "Beispiele"],
               ["maskulin", "Konsonant", "grad, stol, prijatelj"],
               ["feminin", "-a", "žena, kuća, voda"],
               ["neutrum", "-o / -e", "selo, mlijeko, more"]]),
    sec("Wichtige Ausnahmen",
        text="**Feminin auf Konsonant** (i-Deklination): stvar (Sache), noć (Nacht), ljubav (Liebe), sol (Salz), "
             "jesen (Herbst), večer (Abend), obitelj (Familie), kći (Tochter).\n\n"
             "**Maskulin auf -a**: Männer und männliche Berufe – tata, kolega, sudac → pl. suci. Sie werden wie "
             "feminine Wörter dekliniert, Adjektive stehen aber im Maskulinum: „moj tata“.\n\n"
             "**Maskulin auf -o/-e**: einige Lehnwörter und Namen – auto, radio, Marko.",
        examples=[("dobra večer", "guten Abend (večer ist feminin)"), ("moj tata", "mein Papa"),
                  ("novi auto", "das neue Auto (auto ist maskulin)")]),
    sec("Neutra mit Stammerweiterung",
        text="Einige Neutra auf -e bekommen in den anderen Fällen eine Erweiterung: dijete → djeteta, "
             "ime → imena, vrijeme → vremena, rame → ramena.",
        tip="Präge dir bei Ausnahmen gleich das Adjektiv mit ein: „dobra večer“, „laku noć“, „moj tata“. "
            "So merkst du dir das Geschlecht automatisch."),
], [
    Q("Welches Geschlecht hat „kuća“ (Haus)?", ["maskulin", "feminin", "neutrum"], 1, "Endung -a → feminin."),
    Q("Welches Geschlecht hat „more“ (Meer)?", ["maskulin", "feminin", "neutrum"], 2, "Endung -e → neutrum."),
    Q("„noć“ (Nacht) ist …", ["maskulin", "feminin", "neutrum"], 1,
      "Ausnahme: feminin auf Konsonant (i-Deklination)."),
    Q("Richtig ist:", ["moja tata", "moj tata", "moje tata"], 1,
      "tata endet auf -a, ist aber maskulin."),
    Q("Welches Wort ist maskulin?", ["selo", "auto", "voda", "ljubav"], 1, "auto ist ein maskulines Lehnwort."),
])

# ---------------------------------------------------------------------------------------------
lesson("present", "Präsens", "Die drei Konjugationsgruppen -am, -im, -em", [
    sec(text="Im Präsens erkennt man die Gruppe an der **1. Person Singular**. Sie zeigt auch, welcher Vokal in "
             "allen anderen Formen vorkommt. Am besten lernst du jedes Verb mit der ja-Form: čitati – čitam."),
    sec("Die drei Gruppen",
        table=[["", "a-Gruppe\nčitati (lesen)", "i-Gruppe\ngovoriti (sprechen)", "e-Gruppe\npisati (schreiben)"],
               ["ja", "čitam", "govorim", "pišem"],
               ["ti", "čitaš", "govoriš", "pišeš"],
               ["on/ona/ono", "čita", "govori", "piše"],
               ["mi", "čitamo", "govorimo", "pišemo"],
               ["vi", "čitate", "govorite", "pišete"],
               ["oni/one/ona", "čitaju", "govore", "pišu"]]),
    sec("Woran erkenne ich die Gruppe?",
        text="Viele Verben auf **-ati** gehören zur a-Gruppe (čitati, imati, gledati). Viele auf **-iti** und "
             "**-jeti** gehören zur i-Gruppe (govoriti, raditi, voljeti → volim, živjeti → živim). Die e-Gruppe "
             "ist bunt gemischt und hat oft Lautwechsel im Stamm (pisati → pišem, piti → pijem, zvati → zovem)."),
    sec("Wichtige unregelmäßige Verben",
        table=[["Infinitiv", "ja", "ti", "oni"],
               ["ići (gehen)", "idem", "ideš", "idu"],
               ["moći (können)", "mogu", "možeš", "mogu"],
               ["htjeti (wollen)", "hoću", "hoćeš", "hoće"],
               ["jesti (essen)", "jedem", "jedeš", "jedu"],
               ["razumjeti (verstehen)", "razumijem", "razumiješ", "razumiju"]]),
    sec("Beispiele",
        examples=[("Govoriš li njemački?", "Sprichst du Deutsch?"), ("Pišem pismo.", "Ich schreibe einen Brief."),
                  ("Djeca se igraju.", "Die Kinder spielen."), ("Ne mogu danas.", "Ich kann heute nicht.")],
        tip="Die Endung der 3. Person Plural verrät die Gruppe: -aju (a-Gruppe), -e (i-Gruppe), -u (e-Gruppe)."),
], [
    Q("ja + čitati =", ["čitem", "čitam", "čitim", "čitaju"], 1),
    Q("oni + govoriti =", ["govoriju", "govoru", "govore", "govoraju"], 2, "i-Gruppe: 3. Pl. auf -e."),
    Q("ti + pisati =", ["pisaš", "pišeš", "pišiš", "pisiš"], 1, "Lautwechsel s → š: pišem, pišeš."),
    Q("mi + ići =", ["idemo", "ićemo", "imo", "idimo"], 0),
    Q("Welche Form gehört zu „moći“ (ja)?", ["moćem", "mogu", "možem", "moćim"], 1),
])

# ---------------------------------------------------------------------------------------------
lesson("cases_overview", "Die sieben Fälle – Überblick", "Wer? Wessen? Wem? Wen? – und drei mehr", [
    sec(text="Kroatisch hat **sieben Fälle**. Statt Artikeln ändert sich die Endung des Nomens (und der "
             "Adjektive/Pronomen). Das klingt viel, aber vier der Fälle kennst du schon aus dem Deutschen."),
    sec("Die Fälle und ihre Fragen",
        table=[["Fall", "Frage", "wichtigste Verwendung"],
               ["Nominativ", "tko? što?", "Subjekt"],
               ["Genitiv", "koga? čega?", "Besitz, Menge, nach od, do, iz, bez, kod …"],
               ["Dativ", "komu? čemu?", "Empfänger (wem?)"],
               ["Akkusativ", "koga? što?", "direktes Objekt, Richtung (wohin?)"],
               ["Vokativ", "–", "direkte Anrede"],
               ["Lokativ", "o komu? o čemu?", "Ort (wo?) – nur mit Präposition"],
               ["Instrumental", "s kim? čime?", "Begleitung (mit), Mittel"]]),
    sec("Ein Wort in allen Fällen (Singular)",
        table=[["Fall", "grad (m)", "student (m, belebt)", "selo (n)", "žena (f)", "stvar (f)"],
               ["Nom.", "grad", "student", "selo", "žena", "stvar"],
               ["Gen.", "grada", "studenta", "sela", "žene", "stvari"],
               ["Dat.", "gradu", "studentu", "selu", "ženi", "stvari"],
               ["Akk.", "grad", "studenta", "selo", "ženu", "stvar"],
               ["Vok.", "grade", "studente", "selo", "ženo", "stvari"],
               ["Lok.", "gradu", "studentu", "selu", "ženi", "stvari"],
               ["Instr.", "gradom", "studentom", "selom", "ženom", "stvari / stvarju"]]),
    sec("Plural",
        table=[["Fall", "grad (m)", "student (m)", "selo (n)", "žena (f)"],
               ["Nom./Vok.", "gradovi", "studenti", "sela", "žene"],
               ["Gen.", "gradova", "studenata", "sela", "žena"],
               ["Akk.", "gradove", "studente", "sela", "žene"],
               ["Dat./Lok./Instr.", "gradovima", "studentima", "selima", "ženama"]],
        text="Einsilbige Maskulina bekommen im Plural oft **-ov-/-ev-**: grad → gradovi, stol → stolovi.",
        tip="Dativ und Lokativ sind im Singular immer gleich. Und Dativ, Lokativ und Instrumental haben im "
            "Plural dieselbe Form. Statt 14 Formen pro Wort musst du also deutlich weniger lernen."),
], [
    Q("Wie viele Fälle hat das Kroatische?", ["4", "5", "6", "7"], 3),
    Q("Welcher Fall wird für die direkte Anrede verwendet?", ["Nominativ", "Vokativ", "Dativ", "Lokativ"], 1),
    Q("Welcher Fall steht nur mit Präposition?", ["Genitiv", "Akkusativ", "Lokativ", "Instrumental"], 2),
    Q("Dativ und Lokativ Singular sind …", ["immer verschieden", "immer gleich", "nur bei Neutra gleich"], 1),
    Q("Genitiv Singular von „žena“:", ["ženu", "ženi", "žene", "ženom"], 2),
])

# ---------------------------------------------------------------------------------------------
lesson("nominative", "Nominativ", "Der Grundfall – wer oder was?", [
    sec(text="Der Nominativ ist die **Wörterbuchform**. Er steht für das Subjekt und nach „biti“ (sein) "
             "als Prädikat."),
    sec("Verwendung",
        examples=[("Grad je lijep.", "Die Stadt ist schön. (Subjekt)"),
                  ("Ana je studentica.", "Ana ist Studentin. (nach biti)"),
                  ("Boli me glava.", "Mir tut der Kopf weh. (glava ist Subjekt!)"),
                  ("Sviđa mi se kuća.", "Mir gefällt das Haus. (kuća ist Subjekt)")]),
    sec("Plural im Nominativ",
        table=[["Geschlecht", "Singular", "Plural", "Endung"],
               ["maskulin", "stol / student", "stolovi / studenti", "-i (einsilbig oft -ovi/-evi)"],
               ["feminin (-a)", "žena", "žene", "-e"],
               ["feminin (Konsonant)", "stvar", "stvari", "-i"],
               ["neutrum", "selo / more", "sela / mora", "-a"]]),
    sec("Unregelmäßige Plurale",
        examples=[("čovjek → ljudi", "Mensch → Menschen/Leute"), ("dijete → djeca", "Kind → Kinder"),
                  ("brat → braća", "Bruder → Brüder"), ("oko → oči, uho → uši", "Auge → Augen, Ohr → Ohren")],
        tip="Achtung bei „gefallen“ und „wehtun“: Im Kroatischen ist das, was gefällt oder wehtut, das Subjekt im "
            "Nominativ – genau wie im Deutschen „der Kopf tut weh“."),
], [
    Q("„Boli me ___.“ (der Kopf)", ["glavu", "glava", "glave"], 1, "glava ist das Subjekt → Nominativ."),
    Q("Plural von „žena“:", ["žene", "ženi", "ženama", "žena"], 0),
    Q("Plural von „selo“:", ["seli", "sele", "sela", "selovi"], 2),
    Q("Plural von „čovjek“:", ["čovjeci", "čovjeki", "ljudi", "ljude"], 2),
    Q("„Ana je ___.“ (Studentin)", ["studentica", "studenticu", "studentice"], 0,
      "Nach biti steht der Nominativ."),
])

# ---------------------------------------------------------------------------------------------
lesson("genitive", "Genitiv", "Der häufigste Fall nach Präpositionen und Mengen", [
    sec(text="Der Genitiv ist **sehr häufig** – viel häufiger als im Deutschen. Er drückt Besitz und Herkunft "
             "aus, steht nach Mengenangaben, Zahlen und vielen Präpositionen."),
    sec("Endungen",
        table=[["", "Singular", "Plural"],
               ["maskulin / neutrum", "-a (grada, sela)", "-a (gradova, sela) – oft mit -ov-/-a-"],
               ["feminin (-a)", "-e (žene)", "-a (žena)"],
               ["feminin (Konsonant)", "-i (stvari)", "-i (stvari)"]]),
    sec("Präpositionen mit Genitiv",
        text="**od** (von, seit), **do** (bis, zu), **iz** (aus), **bez** (ohne), **kod** (bei), **blizu** (nahe), "
             "**ispred** (vor), **iza** (hinter), **pored** (neben), **zbog** (wegen), **nakon** (nach), "
             "**prije** (vor, zeitlich), **tijekom** (während), **oko** (um … herum)",
        examples=[("Ja sam iz Njemačke.", "Ich bin aus Deutschland."),
                  ("Idem kod bake.", "Ich gehe zur Oma."),
                  ("Kava bez šećera", "Kaffee ohne Zucker"),
                  ("Radim od ponedjeljka do petka.", "Ich arbeite von Montag bis Freitag.")]),
    sec("Mengen und Zahlen",
        text="Nach Mengenwörtern (puno, malo, dovoljno, čaša, kilo …) steht der Genitiv. Bei Zahlen gilt: nach "
             "**2, 3, 4** Genitiv Singular, ab **5** Genitiv Plural.",
        examples=[("čaša vode", "ein Glas Wasser"), ("puno ljudi", "viele Leute"),
                  ("dva piva", "zwei Bier"), ("pet minuta", "fünf Minuten")]),
    sec("Besitz",
        examples=[("kuća mog brata", "das Haus meines Bruders"), ("centar grada", "das Stadtzentrum")],
        tip="Flüchtiges a: Bei vielen Wörtern verschwindet das a der letzten Silbe, sobald eine Endung "
            "dazukommt: petak → petka, novac → novca, centar → centra."),
], [
    Q("„Ja sam iz ___.“ (Deutschland = Njemačka)", ["Njemačka", "Njemačku", "Njemačke", "Njemačkoj"], 2,
      "iz + Genitiv: -a → -e."),
    Q("„Juha je bez ___.“ (sol)", ["sol", "soli", "solom"], 1, "sol ist feminin auf Konsonant → Gen. soli."),
    Q("„dva ___“ (pivo)", ["pivo", "piva", "pive"], 1, "Nach 2, 3, 4 → Genitiv Singular."),
    Q("„pet ___“ (minuta)", ["minute", "minuta", "minutu"], 1, "Ab 5 → Genitiv Plural (minuta)."),
    Q("Genitiv von „petak“ (Freitag):", ["petaka", "petka", "petku"], 1, "Flüchtiges a: petak → petka."),
])

# ---------------------------------------------------------------------------------------------
lesson("dative", "Dativ", "Wem? – der Empfänger", [
    sec(text="Der Dativ bezeichnet die Person, **der etwas gegeben, gesagt oder gezeigt wird**. Er wird auch für "
             "Gefühle und Zustände verwendet („mir ist kalt“)."),
    sec("Endungen",
        table=[["", "Singular", "Plural"],
               ["maskulin / neutrum", "-u (bratu, selu)", "-ima (bratima, selima)"],
               ["feminin (-a)", "-i (ženi)", "-ama (ženama)"],
               ["feminin (Konsonant)", "-i (stvari)", "-ima (stvarima)"]]),
    sec("Lautwechsel bei Feminina",
        text="Endet der Stamm auf **k, g, h**, ändert er sich vor -i: k → c, g → z, h → s.",
        examples=[("ruka → ruci", "Hand"), ("noga → nozi", "Bein"), ("knjiga → knjizi", "Buch"),
                  ("rijeka → rijeci", "Fluss")]),
    sec("Verwendung",
        examples=[("Dajem knjigu bratu.", "Ich gebe dem Bruder das Buch."),
                  ("Pišem pismo mami.", "Ich schreibe Mama einen Brief."),
                  ("Pomažem susjedu.", "Ich helfe dem Nachbarn. (pomoći + Dativ)"),
                  ("Idem liječniku.", "Ich gehe zum Arzt. (zu einer Person)")]),
    sec("Dativpronomen",
        table=[["", "betont", "unbetont"],
               ["mir", "meni", "mi"], ["dir", "tebi", "ti"], ["ihm", "njemu", "mu"], ["ihr", "njoj", "joj"],
               ["uns", "nama", "nam"], ["euch/Ihnen", "vama", "vam"], ["ihnen", "njima", "im"]],
        examples=[("Hladno mi je.", "Mir ist kalt."), ("Sviđa mi se.", "Es gefällt mir."),
                  ("Drago mi je.", "Freut mich.")],
        tip="Viele „Gefühls-Sätze“ funktionieren mit Dativ + je: Hladno mi je, Dosadno mi je (mir ist langweilig), "
            "Žao mi je (es tut mir leid)."),
], [
    Q("„Dajem knjigu ___.“ (Ana)", ["Ana", "Anu", "Ani", "Anom"], 2, "Feminin -a → Dativ -i."),
    Q("„Pišem ___.“ (brat)", ["brat", "brata", "bratu", "bratom"], 2),
    Q("Dativ von „ruka“:", ["ruki", "ruci", "ruku", "ruke"], 1, "k → c vor -i."),
    Q("„Mir ist kalt“:", ["Hladno sam.", "Hladno mi je.", "Ja sam hladan.", "Hladno me je."], 1),
    Q("„Ich helfe meiner Mutter“ – welcher Fall folgt auf pomoći?", ["Akkusativ", "Genitiv", "Dativ", "Instrumental"], 2),
])

# ---------------------------------------------------------------------------------------------
lesson("accusative", "Akkusativ", "Wen oder was? – und wohin?", [
    sec(text="Der Akkusativ ist der Fall des **direkten Objekts**. Mit den Präpositionen u und na drückt er "
             "eine **Richtung** aus (wohin?)."),
    sec("Endungen",
        table=[["", "Singular", "Plural"],
               ["maskulin unbelebt", "= Nominativ (grad)", "-e (gradove)"],
               ["maskulin belebt", "= Genitiv (brata, studenta)", "-e (studente)"],
               ["neutrum", "= Nominativ (selo)", "-a (sela)"],
               ["feminin (-a)", "-u (ženu)", "-e (žene)"],
               ["feminin (Konsonant)", "= Nominativ (stvar)", "-i (stvari)"]]),
    sec("Belebt oder unbelebt?",
        text="Bei **maskulinen** Wörtern kommt es darauf an, ob es ein Lebewesen ist: Dann sieht der Akkusativ wie "
             "der Genitiv aus, sonst wie der Nominativ.",
        examples=[("Vidim grad.", "Ich sehe die Stadt. (unbelebt)"),
                  ("Vidim brata.", "Ich sehe den Bruder. (belebt)"),
                  ("Šetam psa.", "Ich führe den Hund aus. (belebt)")]),
    sec("Wohin? – u / na + Akkusativ",
        examples=[("Idem u školu.", "Ich gehe in die Schule."), ("Idemo na more.", "Wir fahren ans Meer."),
                  ("Stavi to na stol.", "Leg das auf den Tisch.")]),
    sec("Weitere Präpositionen und Zeitangaben",
        text="**za** (für), **kroz** (durch), **uz** (entlang, an … hinauf), **niz** (hinunter). "
             "Wochentage mit u: u ponedjeljak, u subotu.",
        examples=[("Ovo je za tebe.", "Das ist für dich."), ("Vidimo se u subotu.", "Wir sehen uns am Samstag.")],
        tip="Wo? → Lokativ. Wohin? → Akkusativ. „U školi sam“ (in der Schule), aber „Idem u školu“ "
            "(in die Schule)."),
], [
    Q("„Jedem ___.“ (jabuka)", ["jabuka", "jabuke", "jabuku", "jabuci"], 2),
    Q("„Vidim ___.“ (brat)", ["brat", "brata", "bratu"], 1, "Maskulin belebt → Akk. = Gen."),
    Q("„Vidim ___.“ (stol)", ["stol", "stola", "stolu"], 0, "Maskulin unbelebt → Akk. = Nom."),
    Q("„Idem u ___.“ (škola)", ["škola", "školi", "školu", "školom"], 2, "Richtung (wohin?) → Akkusativ."),
    Q("„Volim svoju ___.“ (obitelj)", ["obitelj", "obitelji", "obitelju"], 0,
      "Feminin auf Konsonant: Akk. = Nom."),
])

# ---------------------------------------------------------------------------------------------
lesson("vocative", "Vokativ", "Die Anrede", [
    sec(text="Der Vokativ wird verwendet, wenn man jemanden **direkt anspricht** – mit Namen, Titel oder "
             "Verwandtschaftsbezeichnung."),
    sec("Endungen im Singular",
        table=[["Gruppe", "Endung", "Beispiele"],
               ["maskulin, harter Stamm", "-e", "brat → brate, gospodin → gospodine, Ivan → Ivane"],
               ["maskulin auf -k, -g, -h, -c", "-e mit Lautwechsel", "vojnik → vojniče, stric → striče, Bog → Bože"],
               ["maskulin, weicher Stamm (j, lj, nj, č, ć, š, ž, đ)", "-u", "prijatelj → prijatelju, muž → mužu"],
               ["feminin auf -a", "-o", "žena → ženo, gospođa → gospođo, sestra → sestro"],
               ["feminin auf -ica", "-ice", "učiteljica → učiteljice, prijateljica → prijateljice"],
               ["feminin auf Konsonant", "-i", "kći → kćeri, ljubav → ljubavi"],
               ["neutrum", "= Nominativ", "dijete → dijete"]]),
    sec("Namen",
        text="Männernamen auf Konsonant bekommen meist -e (Ivan → Ivane, Petar → Petre), Namen auf -o bleiben "
             "gleich (Marko). Zweisilbige Frauennamen bleiben oft unverändert (Ana, Maja), längere bekommen -o "
             "(Marija → Marijo)."),
    sec("Beispiele",
        examples=[("Dobar dan, gospodine Horvat!", "Guten Tag, Herr Horvat!"),
                  ("Hvala, gospođo!", "Danke, gnädige Frau!"),
                  ("Dragi prijatelju, …", "Lieber Freund, …"),
                  ("Sretan rođendan, sestro!", "Alles Gute, Schwesterchen!")],
        tip="Im Plural ist der Vokativ immer gleich dem Nominativ: „Dragi prijatelji!“"),
], [
    Q("„Dobar dan, ___!“ (gospodin)", ["gospodin", "gospodine", "gospodinu"], 1),
    Q("„Hvala, ___!“ (gospođa)", ["gospođa", "gospođo", "gospođe"], 1, "Feminin -a → -o."),
    Q("„Dragi ___!“ (prijatelj)", ["prijatelje", "prijatelj", "prijatelju"], 2, "Weicher Stamm (lj) → -u."),
    Q("„Sretan rođendan, ___!“ (sestra)", ["sestra", "sestro", "sestre"], 1),
    Q("Vokativ Plural von „prijatelji“:", ["prijatelji", "prijateljima", "prijatelje"], 0,
      "Im Plural ist der Vokativ gleich dem Nominativ."),
])

# ---------------------------------------------------------------------------------------------
lesson("locative", "Lokativ", "Wo? – und worüber?", [
    sec(text="Der Lokativ steht **immer mit einer Präposition**. Meistens beantwortet er die Frage „wo?“. "
             "Seine Formen sind identisch mit dem Dativ."),
    sec("Endungen",
        table=[["", "Singular", "Plural"],
               ["maskulin / neutrum", "-u (gradu, selu)", "-ima (gradovima, selima)"],
               ["feminin (-a)", "-i (ženi)", "-ama (ženama)"],
               ["feminin (Konsonant)", "-i (stvari)", "-ima (stvarima)"]]),
    sec("Präpositionen mit Lokativ",
        text="**u** (in – wo?), **na** (auf, an – wo?), **o** (über, von – Thema), **po** (auf … herum, durch, "
             "nach), **pri** (bei – eher förmlich)",
        examples=[("Živim u Konstanzu.", "Ich wohne in Konstanz."),
                  ("Knjiga je na stolu.", "Das Buch liegt auf dem Tisch."),
                  ("Razgovaramo o filmu.", "Wir sprechen über den Film."),
                  ("Šetamo po gradu.", "Wir spazieren durch die Stadt.")]),
    sec("u oder na?",
        text="**u** für geschlossene Räume und Städte/Länder (u kuhinji, u Zagrebu, u Njemačkoj). **na** für "
             "offene Flächen, Inseln, Veranstaltungen und einige feste Ausdrücke (na moru, na otoku, na koncertu, "
             "na poslu, na fakultetu).",
        tip="Wo? → Lokativ, wohin? → Akkusativ: „Na moru smo“ (wir sind am Meer), aber „Idemo na more“ "
            "(wir fahren ans Meer)."),
], [
    Q("„Živim u ___.“ (Zagreb)", ["Zagreb", "Zagreba", "Zagrebu", "Zagrebom"], 2),
    Q("„Ključevi su na ___.“ (stol)", ["stol", "stolu", "stola"], 1),
    Q("„Kuham u ___.“ (kuhinja)", ["kuhinju", "kuhinje", "kuhinji"], 2),
    Q("„Pričamo o ___.“ (ljubav)", ["ljubav", "ljubavi", "ljubavom"], 1),
    Q("Welcher Satz drückt einen Ort (wo?) aus?", ["Idem u školu.", "U školi sam.", "Idem na posao."], 1),
])

# ---------------------------------------------------------------------------------------------
lesson("instrumental", "Instrumental", "Mit wem? Womit?", [
    sec(text="Der Instrumental drückt **Begleitung** (mit s/sa) und das **Mittel** aus, mit dem etwas getan "
             "wird (ohne Präposition). Außerdem steht er nach einigen Ortspräpositionen."),
    sec("Endungen",
        table=[["", "Singular", "Plural"],
               ["maskulin / neutrum (harter Stamm)", "-om (gradom, selom)", "-ima"],
               ["maskulin / neutrum (weicher Stamm)", "-em (prijateljem, morem)", "-ima"],
               ["feminin (-a)", "-om (ženom)", "-ama"],
               ["feminin (Konsonant)", "-i / -ju (stvari, ljubavlju)", "-ima"]]),
    sec("Begleitung: s / sa + Instrumental",
        text="**sa** steht vor Wörtern, die mit s, z, š, ž beginnen (und vor mnom): sa sestrom, sa mnom.",
        examples=[("Idem u kino s prijateljem.", "Ich gehe mit einem Freund ins Kino."),
                  ("Kava s mlijekom", "Kaffee mit Milch"),
                  ("Razgovaram sa susjedom.", "Ich spreche mit dem Nachbarn.")]),
    sec("Mittel und Werkzeug – ohne Präposition",
        examples=[("Putujem vlakom.", "Ich fahre mit dem Zug."), ("Pišem olovkom.", "Ich schreibe mit dem Bleistift."),
                  ("Plaćam karticom.", "Ich zahle mit Karte.")]),
    sec("Ortspräpositionen",
        text="**pod** (unter), **nad** (über), **pred** (vor), **za** (hinter), **među** (zwischen) – mit "
             "Instrumental, wenn es um einen Ort geht (wo?).",
        examples=[("Mačka je pod stolom.", "Die Katze ist unter dem Tisch."),
                  ("Sjedimo za stolom.", "Wir sitzen am Tisch.")],
        tip="Mit Verkehrsmitteln nie „s“: „vlakom“, nicht „s vlakom“ – sonst klingt es, als würdest du "
            "zusammen mit dem Zug reisen."),
], [
    Q("„Putujem ___.“ (autobus)", ["s autobusom", "autobusom", "autobusu"], 1, "Mittel → Instrumental ohne Präposition."),
    Q("„Idem u kino ___.“ (sestra)", ["sa sestrom", "s sestru", "sestrom"], 0, "Begleitung → s/sa + Instr.; sa vor s-."),
    Q("Instrumental von „prijatelj“:", ["prijateljom", "prijateljem", "prijatelju"], 1, "Weicher Stamm → -em."),
    Q("„Mačka je pod ___.“ (stol)", ["stol", "stolu", "stolom"], 2),
    Q("„Kava s ___.“ (mlijeko)", ["mlijeko", "mlijekom", "mlijeka"], 1),
])

# ---------------------------------------------------------------------------------------------
lesson("adjectives", "Adjektive", "Übereinstimmung mit dem Nomen", [
    sec(text="Adjektive richten sich in **Geschlecht, Zahl und Fall** nach ihrem Nomen. Im Wörterbuch steht die "
             "maskuline Form."),
    sec("Nominativ",
        table=[["", "maskulin", "feminin", "neutrum"],
               ["Singular", "dobar / dobri", "dobra", "dobro"],
               ["Plural", "dobri", "dobre", "dobra"]],
        examples=[("dobar grad", "eine gute Stadt"), ("dobra kava", "guter Kaffee"), ("dobro vino", "guter Wein")]),
    sec("Unbestimmt und bestimmt",
        text="Maskuline Adjektive haben zwei Formen: **unbestimmt** (dobar – „was für ein?“) und **bestimmt** "
             "(dobri – „welcher?“), ähnlich wie ein/der im Deutschen. Für den Anfang: Nach biti steht meist die "
             "unbestimmte Form (Grad je velik), vor bekannten Dingen die bestimmte (veliki grad – die große Stadt)."),
    sec("Deklination im Singular",
        table=[["Fall", "maskulin", "neutrum", "feminin"],
               ["Nom.", "dobar / dobri", "dobro", "dobra"],
               ["Gen.", "dobrog(a)", "dobrog(a)", "dobre"],
               ["Dat./Lok.", "dobrom(u)", "dobrom(u)", "dobroj"],
               ["Akk.", "= Nom. / Gen.*", "dobro", "dobru"],
               ["Instr.", "dobrim", "dobrim", "dobrom"]],
        text="* unbelebt = Nominativ (dobar stol), belebt = Genitiv (dobrog prijatelja)."),
    sec("Flüchtiges a",
        text="Viele Adjektive verlieren in allen Formen außer dem maskulinen Nominativ das a der letzten Silbe.",
        examples=[("sretan → sretna, sretno", "glücklich"), ("dobar → dobra", "gut"),
                  ("težak → teška", "schwer (mit Lautangleichung ž → š)")],
        tip="Im Plural haben Dativ, Lokativ und Instrumental bei allen Geschlechtern dieselbe Form: dobrim(a)."),
], [
    Q("„___ kava“ (dobar)", ["dobar", "dobra", "dobro"], 1),
    Q("„___ more“ (lijep)", ["lijep", "lijepa", "lijepo"], 2, "more ist neutrum."),
    Q("„Živim u ___ gradu.“ (velik)", ["velikom", "veliku", "velikoj"], 0, "Lokativ maskulin → -om(u)."),
    Q("„Imam ___ prijatelja.“ (dobar)", ["dobar", "dobrog", "dobrom"], 1, "Maskulin belebt im Akkusativ = Genitiv."),
    Q("Feminine Form von „sretan“:", ["sretana", "sretna", "sretan"], 1, "Flüchtiges a."),
])

# ---------------------------------------------------------------------------------------------
lesson("perfect", "Vergangenheit (Perfekt)", "biti + l-Partizip", [
    sec(text="Für die Vergangenheit verwendet man fast immer das **Perfekt**: die Kurzform von biti + das "
             "**l-Partizip**. Das Partizip richtet sich nach dem Geschlecht und der Zahl des Subjekts."),
    sec("Bildung des l-Partizips",
        text="Infinitiv ohne **-ti**, dann die Endungen:",
        table=[["", "maskulin", "feminin", "neutrum"],
               ["Singular", "-o (čitao)", "-la (čitala)", "-lo (čitalo)"],
               ["Plural", "-li (čitali)", "-le (čitale)", "-la (čitala)"]]),
    sec("Konjugation von čitati",
        table=[["Person", "männlich", "weiblich"],
               ["ja", "čitao sam", "čitala sam"],
               ["ti", "čitao si", "čitala si"],
               ["on / ona", "čitao je", "čitala je"],
               ["mi", "čitali smo", "čitale smo"],
               ["vi", "čitali ste", "čitale ste"],
               ["oni / one", "čitali su", "čitale su"]]),
    sec("Unregelmäßige Partizipien",
        table=[["Infinitiv", "maskulin", "feminin"],
               ["ići (gehen)", "išao", "išla"], ["doći (kommen)", "došao", "došla"],
               ["moći (können)", "mogao", "mogla"], ["htjeti (wollen)", "htio", "htjela"],
               ["vidjeti (sehen)", "vidio", "vidjela"], ["jesti (essen)", "jeo", "jela"],
               ["reći (sagen)", "rekao", "rekla"]]),
    sec("Wortstellung, Verneinung, Frage",
        examples=[("Čitao sam knjigu.", "Ich habe ein Buch gelesen."),
                  ("Ja sam čitao knjigu.", "Ich habe ein Buch gelesen. (mit Pronomen)"),
                  ("Nisam bio kod kuće.", "Ich war nicht zu Hause."),
                  ("Jesi li vidio film?", "Hast du den Film gesehen?")],
        tip="Die Kurzform von biti steht an zweiter Stelle im Satz: „Jučer sam bio u gradu“. "
            "Ohne Pronomen beginnt der Satz einfach mit dem Partizip: „Bio sam u gradu.“"),
], [
    Q("„Ich (männlich) habe gelesen“:", ["čitao sam", "čitala sam", "sam čitao", "čitam sam"], 0),
    Q("„Sie (weiblich, Sg.) ist gekommen“:", ["došao je", "došla je", "došla su", "došlo je"], 1),
    Q("l-Partizip maskulin von „ići“:", ["išao", "ićio", "idao", "išlo"], 0),
    Q("„Ich war nicht zu Hause“:", ["Ne sam bio kod kuće.", "Nisam bio kod kuće.", "Bio nisam kod kuće."], 1),
    Q("„Wir (gemischte Gruppe) haben gegessen“:", ["jeli smo", "jele smo", "jeo smo"], 0,
      "Bei gemischten Gruppen steht das Maskulinum."),
])

# ---------------------------------------------------------------------------------------------
lesson("future", "Futur I", "ću, ćeš, će … + Infinitiv", [
    sec(text="Das Futur wird mit der Kurzform von **htjeti** (ću, ćeš, će …) und dem **Infinitiv** gebildet."),
    sec("Formen",
        table=[["Person", "Hilfsverb", "Beispiel", "verneint"],
               ["ja", "ću", "ja ću čitati", "neću čitati"],
               ["ti", "ćeš", "ti ćeš čitati", "nećeš čitati"],
               ["on/ona/ono", "će", "on će čitati", "neće čitati"],
               ["mi", "ćemo", "mi ćemo čitati", "nećemo čitati"],
               ["vi", "ćete", "vi ćete čitati", "nećete čitati"],
               ["oni/one/ona", "će", "oni će čitati", "neće čitati"]]),
    sec("Verb am Satzanfang",
        text="Steht kein Pronomen davor, kommt das Verb zuerst. Dann fällt bei Infinitiven auf **-ti** das i weg: "
             "**čitat ću**, **putovat ćemo**. Bei Infinitiven auf **-ći** bleibt alles: **ići ću**, **doći ćeš**.",
        examples=[("Čitat ću sutra.", "Ich werde morgen lesen."), ("Putovat ćemo u Split.", "Wir werden nach Split reisen."),
                  ("Doći ću u osam.", "Ich komme um acht."), ("Neću doći.", "Ich werde nicht kommen.")]),
    sec("Fragen",
        examples=[("Hoćeš li doći?", "Wirst du kommen?"), ("Što ćeš piti?", "Was wirst du trinken?")],
        tip="In Ja/Nein-Fragen steht die Langform: Hoćeš li …? Hoće li …? Die Kurzantwort ist dann einfach "
            "„Hoću.“ (ja) oder „Neću.“ (nein)."),
], [
    Q("„Ich werde lesen“ (Verb vorne):", ["Čitati ću.", "Čitat ću.", "Čitam ću."], 1, "-ti → -t vor ću."),
    Q("„Wir werden reisen“:", ["mi ćemo putovati", "mi će putovati", "mi smo putovati"], 0),
    Q("„Ich werde nicht kommen“:", ["Ne ću doći.", "Neću doći.", "Nisam doći."], 1),
    Q("„Wirst du kommen?“", ["Ćeš li doći?", "Hoćeš li doći?", "Jesi li doći?"], 1),
    Q("Verb auf -ći am Satzanfang:", ["Ić ću.", "Ići ću.", "Idem ću."], 1, "Bei -ći bleibt der Infinitiv vollständig."),
])

# ---------------------------------------------------------------------------------------------
lesson("aspect", "Verbaspekt", "vollendet oder unvollendet?", [
    sec(text="Fast jedes Verb gibt es in zwei Varianten: **unvollendet** (imperfektiv) für Vorgänge, "
             "Wiederholung und Dauer – und **vollendet** (perfektiv) für einmalige, abgeschlossene Handlungen "
             "mit Ergebnis."),
    sec("Typische Paare",
        table=[["unvollendet", "vollendet", "Bedeutung"],
               ["pisati", "napisati", "schreiben"], ["čitati", "pročitati", "lesen"],
               ["piti", "popiti", "trinken"], ["jesti", "pojesti", "essen"],
               ["kuhati", "skuhati", "kochen"], ["učiti", "naučiti", "lernen"],
               ["kupovati", "kupiti", "kaufen"], ["davati", "dati", "geben"],
               ["dolaziti", "doći", "kommen"], ["otvarati", "otvoriti", "öffnen"]]),
    sec("Unterschied in der Vergangenheit",
        examples=[("Čitao sam knjigu.", "Ich habe (eine Zeit lang) in dem Buch gelesen."),
                  ("Pročitao sam knjigu.", "Ich habe das Buch (zu Ende) gelesen."),
                  ("Svaki dan sam pisao pisma.", "Jeden Tag habe ich Briefe geschrieben. (Wiederholung)"),
                  ("Napisao sam pismo.", "Ich habe den Brief geschrieben. (fertig)")]),
    sec("Perfektive Verben im Präsens",
        text="Ein vollendetes Verb im Präsens beschreibt **keine Handlung, die gerade passiert**. Es steht "
             "z. B. nach **da** (dass/um zu), **kad** (wenn) oder **ako** (falls).",
        examples=[("Želim kupiti kruh.", "Ich möchte Brot kaufen."),
                  ("Ako popiješ kavu, idemo.", "Wenn du den Kaffee ausgetrunken hast, gehen wir."),
                  ("Kad dođeš, nazovi me.", "Wenn du ankommst, ruf mich an.")],
        tip="Faustregel: Gerade jetzt, immer wieder, eine Weile → unvollendet. Einmal, fertig, mit Ergebnis → "
            "vollendet. Im Wörterbuch stehen die Paare meist zusammen."),
], [
    Q("Vollendetes Gegenstück zu „pisati“:", ["napisati", "pisivati", "ispisivati"], 0),
    Q("„Ich habe das Buch zu Ende gelesen“:", ["Čitao sam knjigu.", "Pročitao sam knjigu."], 1),
    Q("„Jeden Tag trinke ich Kaffee“ – welcher Aspekt?", ["unvollendet (pijem)", "vollendet (popijem)"], 0,
      "Wiederholung → unvollendet."),
    Q("„dolaziti“ ist …", ["vollendet", "unvollendet"], 1),
    Q("Welches Verb kann nicht für eine gerade laufende Handlung im Präsens stehen?", ["kupovati", "kupiti", "čitati"], 1,
      "kupiti ist vollendet."),
])

# ---------------------------------------------------------------------------------------------
lesson("questions", "Fragen & Verneinung", "li, tko, što … und ne", [
    sec("Ja/Nein-Fragen mit li",
        text="Die Partikel **li** steht direkt nach dem Verb, das am Satzanfang steht. Bei biti benutzt man "
             "dafür die Langform.",
        examples=[("Govoriš li njemački?", "Sprichst du Deutsch?"), ("Imaš li vremena?", "Hast du Zeit?"),
                  ("Jesi li umoran?", "Bist du müde?"), ("Je li to tvoja kuća?", "Ist das dein Haus?")]),
    sec("Fragewörter",
        table=[["Kroatisch", "Deutsch"],
               ["tko", "wer"], ["što", "was"], ["gdje", "wo"], ["kamo", "wohin"], ["odakle", "woher"],
               ["kada / kad", "wann"], ["zašto", "warum"], ["kako", "wie"], ["koliko", "wie viel"],
               ["koji, koja, koje", "welcher, welche, welches"], ["čiji, čija, čije", "wessen"]],
        examples=[("Odakle si?", "Woher kommst du?"), ("Kamo ideš?", "Wohin gehst du?"),
                  ("Koliko košta?", "Wie viel kostet das?")]),
    sec("Verneinung",
        text="**ne** steht direkt vor dem Verb. Drei Verben haben eigene verneinte Formen: biti → **nisam**, "
             "imati → **nemam**, htjeti → **neću**.",
        examples=[("Ne razumijem.", "Ich verstehe nicht."), ("Nemam vremena.", "Ich habe keine Zeit."),
                  ("Nisam gladan.", "Ich habe keinen Hunger.")]),
    sec("Doppelte Verneinung",
        text="Anders als im Deutschen ist die mehrfache Verneinung **Pflicht**: nitko (niemand), ništa (nichts), "
             "nikad (nie), nigdje (nirgends) stehen immer zusammen mit ne.",
        examples=[("Nitko ništa ne zna.", "Niemand weiß etwas."), ("Nikad nisam bio tamo.", "Ich war nie dort.")],
        tip="„Da li …?“ hört man oft, gilt im Standardkroatischen aber als Serbismus – besser: „Je li …?“ "
            "bzw. Verb + li."),
], [
    Q("„Hast du Zeit?“", ["Li imaš vremena?", "Imaš li vremena?", "Imaš vremena li?"], 1),
    Q("„wohin“ heißt …", ["gdje", "kamo", "odakle"], 1),
    Q("Verneinung von „imam“:", ["ne imam", "nemam", "nimam"], 1),
    Q("„Niemand weiß etwas“:", ["Nitko zna ništa.", "Nitko ništa ne zna.", "Netko ništa zna."], 1,
      "Doppelte Verneinung ist Pflicht."),
    Q("„Bist du müde?“", ["Si li umoran?", "Jesi li umoran?", "Je li umoran si?"], 1, "In Fragen: Langform von biti + li."),
])

# ---------------------------------------------------------------------------------------------
lesson("possessives", "Possessivpronomen", "mein, dein, sein … und svoj", [
    sec("Formen",
        table=[["Person", "maskulin", "feminin", "neutrum", "Deutsch"],
               ["ja", "moj", "moja", "moje", "mein"], ["ti", "tvoj", "tvoja", "tvoje", "dein"],
               ["on / ono", "njegov", "njegova", "njegovo", "sein"],
               ["ona", "njezin (njen)", "njezina", "njezino", "ihr"],
               ["mi", "naš", "naša", "naše", "unser"], ["vi", "vaš", "vaša", "vaše", "euer / Ihr"],
               ["oni", "njihov", "njihova", "njihovo", "ihr (Pl.)"]],
        text="Wie Adjektive richten sie sich nach dem **besessenen Nomen**, nicht nach dem Besitzer."),
    sec("Beispiele",
        examples=[("moj brat, moja sestra, moje dijete", "mein Bruder, meine Schwester, mein Kind"),
                  ("Njegova kuća je velika.", "Sein Haus ist groß."),
                  ("Gdje su vaše torbe?", "Wo sind Ihre Taschen?")]),
    sec("Das Reflexivpossessiv svoj",
        text="**svoj** bedeutet „sein eigenes“ und bezieht sich immer auf das **Subjekt** des Satzes – egal in "
             "welcher Person. Im Deutschen gibt es das nicht.",
        examples=[("Volim svoju obitelj.", "Ich liebe meine Familie."),
                  ("Marko voli svoju ženu.", "Marko liebt seine (eigene) Frau."),
                  ("Marko voli njegovu ženu.", "Marko liebt seine (die eines anderen) Frau!")]),
    sec("Deklination von moj (Singular)",
        table=[["Fall", "maskulin", "feminin"],
               ["Nom.", "moj", "moja"], ["Gen.", "mojeg(a) / mog(a)", "moje"], ["Dat./Lok.", "mojem(u) / mom(u)", "mojoj"],
               ["Akk.", "moj / mojeg(a)", "moju"], ["Instr.", "mojim", "mojom"]],
        tip="Wenn der Besitzer das Subjekt ist, nimm svoj: „Zovem svoju mamu“ – nicht „moju mamu“ (das ist "
            "zwar verständlich, aber svoj ist üblicher)."),
], [
    Q("„meine Schwester“:", ["moj sestra", "moja sestra", "moje sestra"], 1),
    Q("„unser Haus“ (kuća):", ["naš kuća", "naša kuća", "naše kuća"], 1),
    Q("„Ana liebt ihren (eigenen) Bruder“:", ["Ana voli njezinog brata.", "Ana voli svog brata."], 1,
      "Bezug auf das Subjekt → svoj."),
    Q("„dein Kind“ (dijete):", ["tvoj dijete", "tvoja dijete", "tvoje dijete"], 2, "dijete ist neutrum."),
    Q("Possessivpronomen richten sich nach …", ["dem Besitzer", "dem besessenen Nomen"], 1),
])

# ---------------------------------------------------------------------------------------------
lesson("clitics", "Wortstellung & Klitika", "Die kleinen Wörter an zweiter Stelle", [
    sec(text="Die Wortstellung im Kroatischen ist recht frei. Eine feste Regel gibt es aber: **Klitika** "
             "(unbetonte Kurzwörter) stehen immer an **zweiter Stelle** im Satz – nach dem ersten betonten Wort "
             "oder Satzglied."),
    sec("Was sind Klitika?",
        text="li; die Kurzformen von biti (sam, si, je …) und htjeti (ću, ćeš …); die unbetonten Pronomen im "
             "Dativ (mi, ti, mu, joj …) und Akkusativ/Genitiv (me, te, ga, je, nas, vas, ih); und se."),
    sec("Reihenfolge, wenn mehrere zusammenkommen",
        table=[["1", "2", "3", "4", "5", "6"],
               ["li", "Verb-Klitikon (sam, ću … – außer je)", "Dativ (mi, mu …)", "Akkusativ/Genitiv (ga, je …)", "se", "je"]],
        examples=[("Dao sam mu ga.", "Ich habe es ihm gegeben."),
                  ("Jesi li mu ga dao?", "Hast du es ihm gegeben?"),
                  ("On mu ga je dao.", "Er hat es ihm gegeben. (je ganz am Ende)"),
                  ("Sviđa mi se.", "Es gefällt mir.")]),
    sec("Zweite Stelle in der Praxis",
        examples=[("Ja sam ti rekao.", "Ich habe es dir gesagt."),
                  ("Jučer sam ti rekao.", "Gestern habe ich es dir gesagt."),
                  ("Rekao sam ti.", "Ich habe es dir gesagt."),
                  ("Moj brat mi je pomogao.", "Mein Bruder hat mir geholfen.")],
        tip="Klitika können nie am Satzanfang stehen. Wenn du mit dem Verb beginnst, folgen sie direkt danach: "
            "„Zovem se Ana“ – nie „Se zovem Ana“."),
], [
    Q("Richtig ist:", ["Se zovem Ana.", "Zovem se Ana.", "Zovem Ana se."], 1),
    Q("„Ich habe es ihm gegeben“:", ["Dao sam ga mu.", "Dao sam mu ga.", "Dao mu sam ga."], 1, "Dativ vor Akkusativ."),
    Q("Wo steht „je“ in einer Klitika-Gruppe?", ["ganz am Anfang", "ganz am Ende", "nach li"], 1),
    Q("„Es gefällt mir“:", ["Mi se sviđa.", "Sviđa mi se.", "Sviđa se mi."], 1),
    Q("„Gestern habe ich es dir gesagt“:", ["Jučer sam ti rekao.", "Jučer rekao sam ti.", "Sam ti jučer rekao."], 0),
])


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    target = os.path.join(here, "..", "app", "src", "main", "assets", "content", "grammar.json")
    with open(target, "w", encoding="utf-8") as f:
        json.dump({"lessons": LESSONS}, f, ensure_ascii=False, indent=1)
    print(f"{len(LESSONS)} lessons, {sum(len(l['quiz']) for l in LESSONS)} quiz questions")
