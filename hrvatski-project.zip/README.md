# Hrvatski – Croatian for German speakers

An offline Android app for learning Croatian. It has four parts:

- **Karten** (flashcards): German ↔ Croatian cards with spaced repetition.
- **Liste** (word list): every word with both translations, grouped by topic.
- **Üben** (fill-in-the-blank): sentences where you put the word into the right case form.
- **Grammatik** (grammar): 19 lessons with tables, examples and a quiz.

The design is black and white only. There are no accounts, no ads and no tracking, and nothing goes over the network.

| | |
|---|---|
| Content | 14 topics · 440 words · 166 fill-in sentences · 19 grammar lessons · 95 quiz questions |
| Tech | Kotlin, Jetpack Compose, Material 3, Room, kotlinx.serialization |
| Android | 8.0 (API 26) or newer |

---

## 1. Getting the APK

### Option A: GitHub Actions (no Android Studio needed)

1. Create a free account on [github.com](https://github.com) and a **new repository** (it can be private).
2. Upload the **contents** of this folder. On the repository page, click **"uploading an existing file"**, drag in all files and folders, then **Commit**.
   > **Check:** the folder `.github/workflows` is hidden on many computers and is often left out of the upload. If no **Actions** run starts after you upload, go to **Actions → "set up a workflow yourself"**, paste in the contents of `.github/workflows/build-apk.yml` and commit.
3. Open the **Actions** tab. The build takes about 5–8 minutes.
4. Download the APK, either from:
   - **Releases** (right side of the repository page) → *Hrvatski (latest build)* → `Hrvatski.apk`. This is the easiest way to get it straight onto your phone.
   - **or** Actions → the latest run → *Artifacts* → `Hrvatski-APK`. This one comes as a zip file.

Each new push builds a new APK. All builds are signed with the same key (`keystore/debug.keystore`), so a new APK installs as an update and your learning progress is kept.

### Option B: Android Studio

1. Install [Android Studio](https://developer.android.com/studio) and open this folder.
2. Wait for the Gradle sync to finish.
3. Either connect your phone with USB debugging on and press **Run ▶**,
   or go to **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
   The file ends up in `app/build/outputs/apk/debug/app-debug.apk`.

From the command line (JDK 17 and the Android SDK must be installed):

```bash
./gradlew assembleDebug        # build the APK
./gradlew testDebugUnitTest    # run the logic unit tests
```

## 2. Installing on your phone (sideloading)

1. Open the APK on your phone, from the Downloads app or the browser.
2. Android will ask for permission to *install unknown apps* from that app (Chrome, Files …). Allow it in the settings screen that appears, then go back.
3. Tap **Install**. If Play Protect shows a warning about an unknown developer, choose **Install anyway**. The app is yours and isn't on the Play Store, so this warning is expected.

## 3. Changing or adding words and sentences

All learning content is in two JSON files:

```
app/src/main/assets/content/vocabulary.json   ← topics, words, fill-in sentences
app/src/main/assets/content/grammar.json      ← grammar lessons and quizzes
```

You can edit them in any text editor, or directly on GitHub (pencil icon). After you save or commit, rebuild the APK. On the next launch the app detects that the content changed and updates its database. **Your learning progress is kept.** Only words you deleted lose their progress.

### Adding a word

```json
{ "id": "food.burek", "cat": "food", "de": "der Burek", "hr": "burek", "gender": "m", "info": "Gen. bureka" }
```

| Field | Required | Meaning |
|---|---|---|
| `id` | yes | Unique, never change it later (progress is stored under it) |
| `cat` | yes | Topic id, e.g. `food`, `travel` (see `categories`) |
| `de` / `hr` | yes | German / Croatian (base form) |
| `gender` | no | `m`, `f`, `n`, `pl m`, `pl f`, `pl n` |
| `info` | no | Extra grammar info, shown on the back of the card |
| `exDe` / `exHr` | no | Example sentence (German / Croatian) |

### Adding a fill-in sentence

```json
{
  "id": "food.s20", "cat": "food", "word": "food.jabuka",
  "text": "Volim ___.", "answer": "jabuke", "alt": [],
  "distractors": ["jabuka", "jabuku", "jabukom"],
  "hint": "der Apfel (Pl.)", "base": "jabuka",
  "note": "Akkusativ Pl. feminin", "de": "Ich mag Äpfel."
}
```

- `text` must contain exactly one `___`.
- `answer` is the correctly **inflected** form. `alt` lists other spellings that also count as correct.
- `distractors` are the 3 wrong options for multiple-choice mode. Other case forms of the same word work best.
- `word` (optional) links the sentence to a word. A wrong answer sends that word back to Leitner box 1.

### Adding a topic

Add an entry to `categories`, `{ "id": "music", "de": "Musik", "hr": "Glazba" }`, and then use `"cat": "music"` in your words.

### Grammar lessons

Each lesson in `grammar.json` has `sections` and `quiz`. A section may contain any of these: `heading`, `text` (with `**bold**`), `table` (`headers` + `rows`), `examples` (`hr` + `de`) and `tip`. For quiz questions, `answer` is the **index** of the correct option, starting at 0.

If a JSON file contains an error (e.g. a missing comma or an unknown topic id), the app shows the error message on startup instead of crashing. That makes typos easy to find.

The folder `tools/` contains the Python scripts that generated both JSON files (`python3 tools/build_vocabulary.py`). You don't need them: editing the JSON files directly is fine. If you do use them, though, re-running a script **overwrites** any manual edits you made to its JSON file.

---

## 4. How it works

### Spaced repetition (Leitner system)

| Box | Next review |
|---|---|
| 0 | new |
| 1 | immediately (after a wrong answer) |
| 2 | after 1 day |
| 3 | after 3 days, from here on the word counts as **learned** |
| 4 | after 7 days |
| 5 | after 14 days |

A correct answer moves the word up one box. A wrong answer sends it back to box 1. Each card round has up to 20 cards: due reviews come first, then new words.

### Checking typed answers

- Case, spaces and punctuation are ignored.
- The **lenient mode** (in Settings or the Practice tab) accepts answers without diacritics (`cevapi` for `ćevapi`, `dj` for `đ`), but marks them as "almost correct".
- There are buttons for č ć đ š ž above the keyboard.

### Project structure

```
app/src/main/java/de/lern/hrvatski/
├── HrvatskiApplication.kt     app singletons, content sync on start
├── MainActivity.kt            theme + edge-to-edge
├── domain/                    pure Kotlin logic (unit tested)
│   ├── Leitner.kt             spaced-repetition rules
│   ├── AnswerChecker.kt       answer comparison incl. lenient mode
│   ├── TextNormalizer.kt      diacritic folding for search/answers
│   ├── Streak.kt              daily streak
│   └── Settings.kt            settings/stat models
├── data/
│   ├── Repository.kt          single entry point for the UI
│   ├── db/                    Room: entities, DAOs, database
│   ├── seed/                  JSON models + ContentSeeder (JSON → Room)
│   └── grammar/               lesson models + loader
└── ui/                        Compose screens + ViewModels (MVVM)
    ├── AppRoot.kt             scaffold, header (streak), bottom navigation
    ├── cards/  list/  practice/  grammar/  settings/
    ├── common/                shared components (pills, segmented control …)
    └── theme/                 black & white Material 3 theme
```

### Database schema (Room)

| Table | Content | Source |
|---|---|---|
| `categories` | id, nameDe, nameHr, sortOrder | JSON (re-synced) |
| `words` | id, categoryId, german, croatian, gender, info, examples | JSON (re-synced) |
| `sentences` | id, categoryId, wordId, text, answer, alternatives, distractors, hint, baseForm, note, translation | JSON (re-synced) |
| `progress` | wordId, box, dueAt, lastReviewed, correct, wrong | user |
| `lesson_progress` | lessonId, completed, bestScore, total | user |
| `activity` | epochDay, reviews (for the streak) | user |
| `settings` | name, value (theme, card direction, lenient mode) | user |
